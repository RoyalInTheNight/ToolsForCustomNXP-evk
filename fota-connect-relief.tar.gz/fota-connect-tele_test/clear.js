const fs = require('fs')


for (let path of fs.readdirSync('.')){
   if (path == '.git' || path == 'clear.js') continue
   console.log(path)
   fs.rmSync(path, {recursive: true})
}