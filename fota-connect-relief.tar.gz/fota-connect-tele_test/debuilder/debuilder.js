const fs = require('fs')
const path = require('path')
const { platform } = require('os')
const child = require('child_process')

const serviceTemplate = `[Unit]
  Description=%s
  %s

[Service]
  ExecStart=%s %s
  Restart=always
  User=root
  Group=root
  %s
  WorkingDirectory=%s
  %s
[Install]
  WantedBy=multiuser.target
`
const targetTemplate = `[Unit]
  Description=%s
  %s
  `

const format = (...args) => args.shift().replace(/%([jsd])/g, x => x === '%j' ? JSON.stringify(args.shift()) : args.shift())

const _path = {
   configDebuilder: './config.json',
   dist: './../dist',
   ssl_keys: './../openssl_key_pair',
   emulators: './../emulation',
   configFota: './../data',
}

for (let key of Object.keys(_path)) {
   if (!fs.existsSync(_path[key])) {
      console.warn(`ERROR: Please, check ${key} (path ${_path[key]}) and restart debuilder.`)
      process.exit(0)
   }
}

const configDeb = JSON.parse(fs.readFileSync(_path.configDebuilder, 'utf-8'))

//собраем Директории
console.log('Create directories')
fs.mkdirSync(path.join(configDeb.project_name, configDeb.linux_working_dir), { recursive: true })
for (let _code of configDeb.code) {
   if (path.isAbsolute(_code.target)) {
      fs.cpSync(_code.source, path.join(configDeb.project_name, _code.target), { recursive: true })
   }
   else {
      fs.cpSync(_code.source, path.join(configDeb.project_name, configDeb.linux_working_dir, _code.target), { recursive: true })
   }
}

//Собираем сервисы
console.log('Create services')
fs.mkdirSync(path.join(__dirname, configDeb.project_name, configDeb.linux_services.path), { recursive: true })
for (let service of configDeb.linux_services.collection) {
   let envs = ''
   let requires = ''
   let after = ''
   if ('env' in service) {
      envs = service.env.map(value => `Environment=${value}`).join('\n  ')
   }

   if ('requires' in service) {
      requires = service.requires.map(value => `Requires=${value}`).join('\n  ')
   }
   if ('after' in service) {
      after = `After=${service.after.join(' ')}`
   }
   const comand = process.platform === 'linux' ? 'which node' : 'where node'

   const s = format(serviceTemplate,
      service.service_name,
      after,
      child.execSync(comand).toString().trim() ?? '/usr/bin/node',
      path.join('/', configDeb.linux_working_dir, service.working_subdir, service.exec_file),
      envs,
      path.join('/', configDeb.linux_working_dir, service.working_subdir),
      requires)

   fs.writeFileSync(path.join(__dirname, configDeb.project_name, configDeb.linux_services.path, `${service.service_name}.service`), s)
}
//Собираем .target
if (configDeb.linux_services.target_build) {
   console.log('Create .target')
   const targetServices = configDeb.linux_services.collection.map(value => `Requires=${value.service_name}.service`).join('\n\t')
   const t = format(targetTemplate, `${configDeb.project_name} target`, targetServices)
   fs.writeFileSync(path.join(__dirname, configDeb.project_name, configDeb.linux_services.path, `${configDeb.project_name}.target`), t)
}


if ('postinst_path' in configDeb.linux_debian) {
   console.log('Create postinstal')
   const postinst = configDeb.linux_services.collection.map(value => `systemctl enable ${value.service_name}\nsystemctl start ${value.service_name}`).join('\n')
   // const postinst = `systemctl enable ${configDeb.project_name}.target\nsystemctl start ${configDeb.project_name}.target`
   fs.writeFileSync(path.join(__dirname, configDeb.project_name, configDeb.linux_debian.postinst_path), postinst)
}

if (configDeb && process.platform === 'linux') {
   const chmodCmd = 'chmod 775 ./fota/DEBIAN/postinst'
   const buildCmd = `fakeroot dpkg-deb --build ${configDeb.project_name}`
   const checkCmd = `lintian  ${configDeb.project_name}.deb`

   if ('postinst_path' in configDeb.linux_debian) {
      child.execSync(chmodCmd)
   }

   child.execSync(buildCmd)
   fs.renameSync(`${configDeb.project_name}.deb`, `${configDeb.project_name}_${configDeb.version}.deb`)
   // child.execSync(checkCmd)
}
