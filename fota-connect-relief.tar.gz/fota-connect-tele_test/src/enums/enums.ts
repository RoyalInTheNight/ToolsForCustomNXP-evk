/** Список уровней логирования */
export enum logLevel {
    TRACE = 'trace',
    DEBUG = 'debug',
    INFO = 'info',
    WARN = 'warn',
    ERROR = 'error',
    CRITICAL = 'critical'
}

export enum mPacketTitles {
    CAR_MANIFEST='MANIFEST',
    FOTA_REPORT='FOTA_REPORT',
    TELE_TEST='TELE_TEST'
}

/**
 * Список событий генерируемых приложением
 * */
export enum eventNames {
    NETWORK_ERROR = 'network_error',
    CONNECTION_READY = 'connection_ready',
    FIRMWARE_INSTALLATION_STATUS_DONE = 'firmware_installation_status_done',
    FIRMWARE_INSTALLATION_STATUS_ERROR = 'firmware_installation_status_error',
    ARTIFACTS_IS_READY = 'artifacts_is_ready',
    HANDLE_ERROR = 'handle_error',
    WIALON_DATA_RECEIVED = 'wialon_data_received',
    GPS_DATA_RECEIVED = 'gps_data_received',
    SYSTEM_STATUS_CHANGE = 'system_status_change',
    SEND_MESSAGE_TO_CLOUD = 'send_message_to_cloud',
    HAS_NEW_MANIFEST = 'has_new_manifest',
}

/**
 * Список состояний системы
 * */
export enum systemStatus {
    APP_START = "app_start",
    /** Принят */
    ACCEPTED = "accepted",
    /** Скачивание артефактов */
    DOWNLOADED_ARTIFACTS = "downloaded_artifacts",
    /** Ожидание подтверждения */
    CONFIRMATION_PENDING = "confirmation_pending",
    /** Установка артефактов */
    ARTIFACT_INSTALLATION = "artifact_installation",
    /** Ошибка скачивания */
    DOWNLOADED_ERROR = "downloaded_error",
    /** Ошибка установки */
    INSTALLATION_ERROR = "installation_error",
    /** Установлен */
    INSTALLED = "installed",
    /** Ожидание соединения */
    WAIT_CONNECTION = "wait_connection",
    /** Ожидание манифеста */
    WAIT_MANIFEST = "wait_manifest",
}

/**
 * Список статусов установки артефактов для ответа серверу.
 * */
export enum firmwareStatus{
    /** Скачивание */
    DOWNLOAD,
    /** Установка */
    INSTALL,
    /** Установлен */
    INSTALLED,
    /** Ошибка установки */
    INSTALL_ERROR
}

/**
 * Значениями download_status_code
 * */
export enum firmwareStatusDownload {
    INCORRECT = -1,
    NEED_DOWNLOAD= 2,
    READY = 5
}

/**
 * Список статусов установки артефактов для общения между Master-Connect.
 * */
export enum firmwareStatusFota{
    /** Скачивание */
    NOT_PROCESSED,
    /** Установка */
    UPDATE,
    /** Ошибка установки */
    INSTALL_ERROR
}

/**
 * Типы артефактов
 * */
export enum ArtifactTypes{
    AES_IV = 'aes_iv',
    AES_KEY = 'aes_key',
    FIRMWARE = 'firmware',
    SCRIPT = 'script'
}
