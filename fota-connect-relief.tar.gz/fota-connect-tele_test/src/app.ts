import {EventEmitter} from 'node:stream'
import fs from 'node:fs'
import path from 'path'
import {
  sleep,
  checkAndMakeDir,
  checkNetInterface,
  fotaEventEmitter,
  loadFileDataAsObject, checkAbsolutePath,
} from './utils'
import {
  CryptoManager,
  DiscoveryManager,
  FotaManager,
  KcManager,
  LogManager,
  SystemStatusManager,
  TeleManager,
  UpmManager,
  ErrorHandler, Reporter,
} from './services'
import {IArtifactUpm, IEnv, IFotaError, IHttpsRequestOptions, ILogLastEntry, IUpm} from './interfaces/interfaces'
import {ArtifactTypes, eventNames, mPacketTitles, systemStatus} from './enums/enums'
import {
  LargeSizeFilesError,
  NetInterfaceNotUpError,
  RuntimeConnectionSocketMasterError,
  NoSocketMasterError,
  NotAccessError,
  NoExistsFilesError, SmallSizeFilesError,
} from './errors/errors'


export class App {
  private static instance: App

  readonly logManager: LogManager
  readonly cryptoManager: CryptoManager
  readonly systemStatus: SystemStatusManager
  readonly errorHandler: ErrorHandler
  readonly reporter: Reporter

  readonly fotaManager: FotaManager | null = null
  readonly teleManager: TeleManager | null = null
  readonly discoveryManager: DiscoveryManager | null = null
  // readonly relManager: RelManager

  readonly fotaEventEmitter: EventEmitter
  readonly kcManager: KcManager
  readonly upmManager: UpmManager

  private interfaceNameCount = 0

  private isManifestHandle = false

  checkOrDownloadInProgress: boolean
  logLastEntryData: ILogLastEntry | null

  private constructor(
    private readonly envConfigData: IEnv,
    private readonly blockId: string,
    private readonly blockLogin: string,
  ) {
    this.checkOrDownloadInProgress = false
    this.logLastEntryData = null

    this.fotaEventEmitter = fotaEventEmitter

    //Проверка существования директорий downloads и logs
    checkAndMakeDir(envConfigData.DOWNLOADS_DIRECTORY_PATH)
    checkAndMakeDir(envConfigData.LOGS_DIRECTORY_PATH)

    this.logManager = LogManager.getInstance(
      envConfigData.LOG_LEVEL,
      envConfigData.LOGS_DIRECTORY_PATH,
      envConfigData.LOG_FILE,
      envConfigData.LOG_LAST_ENTRY_FILE,
    )

    this.reporter = Reporter.getInstance(this.logManager)

    this.errorHandler = ErrorHandler.getInstance(this.logManager)

    this.systemStatus = SystemStatusManager.getInstance(
      systemStatus.WAIT_CONNECTION,
      this.logManager,
    )

    this.cryptoManager = CryptoManager.getInstance(
      envConfigData.DOWNLOADS_DIRECTORY_PATH,
      envConfigData.DECRYPT_REPORT_FILE,
      envConfigData.PRIVATE_PEM_PATH,
      this.logManager,
      this.reporter
    )

    this.upmManager = UpmManager.getInstance(
      envConfigData.DOWNLOADS_DIRECTORY_PATH,
      envConfigData.DOWNLOAD_REPORT_FILE,
      this.logManager,
      this.reporter
    )

    if (Number(envConfigData.DISCOVERY_MANAGER) == 1) {
      this.discoveryManager = DiscoveryManager.getInstance(
        envConfigData.PRIVATE_PEM_PATH,
        parseFloat(envConfigData.TIME_DELAY_READ_DISCOVERY),
        this.cryptoManager,
      )
    }
    if (Number(envConfigData.TELE_MANAGER) == 1) {
      this.teleManager = TeleManager.getInstance(
        envConfigData.TELE_IPC_SOCKET_PATH,
        this.logManager,
        this.errorHandler,
      )
    }
    if (Number(envConfigData.FOTA_MANAGER) == 1) {
      this.fotaManager = FotaManager.getInstance(
        envConfigData.DOWNLOADS_DIRECTORY_PATH,
        envConfigData.FOTA_IPC_SOCKET_PATH,
        this.logManager,
        this.errorHandler,
      )
    }

    // this.relManager = RelManager.getInstance(envConfigData.RELIEF_IPC_SOCKET_PATH, this.logManager)

    this.kcManager = KcManager.getInstance({
      blockLogin: this.blockLogin,
      kcHost: envConfigData.KAMAZ_CLOUD_HOST,
      kcPort: Number(envConfigData.KAMAZ_CLOUD_PORT),
      logManager: this.logManager,
      systemStatusManager: this.systemStatus,
      errorHandler: this.errorHandler,
    })
  }

  /**
   * Получение экземпляра класса App
   * @param envConfigData — данные из файла конфигурации FOTA.Connect
   * @param blockId — ID блока
   * @param blockLogin — login блока
   */
  static getInstance = (envConfigData: IEnv, blockId: string, blockLogin: string): App => {
    if (!App.instance) {
      App.instance = new App(envConfigData, blockId, blockLogin)
    }
    return App.instance
  }

  private newManifestListener = async (data: any) => {
    if (!this.isManifestHandle) {
      this.isManifestHandle = true
      try {
        if (this.systemStatus.systemStatus != systemStatus.WAIT_MANIFEST) {
          fotaEventEmitter.emit(eventNames.SEND_MESSAGE_TO_CLOUD, {
            title: mPacketTitles.FOTA_REPORT,
            message: 'I am busy.',
          })
          return
        }

        const upmData = await this.downloadUpm(data)
        this.mainLifeCycle(upmData)
      } catch (e) {
        this.errorHandler.handle(<IFotaError>e)
        if (!('_logLevel' in (e as Error))) {
          this.logManager.log2Console(502, e)
        }
        fotaEventEmitter.emit(eventNames.SYSTEM_STATUS_CHANGE, systemStatus.WAIT_MANIFEST)
      } finally {
        this.isManifestHandle = false
      }
    }
  }

  private mainLifeCycle = async (upmData: IUpm) => {
    try {
      this.systemStatus.systemStatus = systemStatus.DOWNLOADED_ARTIFACTS

      this.checkManifest(upmData)
      await this.downloadArtifacts(upmData)
      this.checkArtifacts(upmData)
      if (upmData.artifacts.filter((value: IArtifactUpm) => value.type == ArtifactTypes.AES_IV || value.type == ArtifactTypes.AES_KEY).length != 0) {
        this.decryptArtifacts(upmData)
      }
      else {
        for (let artifact of upmData.artifacts) {
          fs.cpSync(
            checkAbsolutePath(`${this.envConfigData.DOWNLOADS_DIRECTORY_PATH}/${artifact.file_name}`),
            checkAbsolutePath(`${this.envConfigData.DOWNLOADS_DIRECTORY_PATH}/decrypted/${artifact.file_name}`),
          )
        }
      }

      fotaEventEmitter.emit(eventNames.ARTIFACTS_IS_READY)
      return
    } catch (e) {
      if (e instanceof SmallSizeFilesError || e instanceof NoExistsFilesError) {
        this.errorHandler.handle(e)
        setTimeout(() => this.mainLifeCycle(upmData), 2000)
      }
      if (e instanceof LargeSizeFilesError) {
        this.errorHandler.handle(e)
        // Нужно отправить отчет на клауд
      }
    }
  }

  /**
   * Метод запускает основные этапы ЖЦ приложения FOTA.Connect
   */
  async start(): Promise<void> {
    try {
      // TODO: вынести это в ошибки
      if (Number(this.envConfigData.FOTA_MANAGER) == 1) {
        await this.fotaManager?.start()
      }
      if (Number(this.envConfigData.TELE_MANAGER) == 1) {
        await this.teleManager?.start()
      }

      // Если OS является видом Linux
      if (process.platform === 'linux') {
        // Проверка поднят сетевой интерфейс или нет
        const interfaceName = (this.interfaceNameCount < 5) ? this.envConfigData.NET_INTERFACE : 'eth0'
        if (await checkNetInterface(interfaceName) != 'up') {
          throw new NetInterfaceNotUpError(this.envConfigData.NET_INTERFACE)
        }
      }

      fotaEventEmitter.on(eventNames.CONNECTION_READY, async () => {
        this.logManager.log2Console(500, `CONNECTION_READY`)

        this.systemStatus.systemStatus = systemStatus.WAIT_MANIFEST
        try {
          // Загрузка данных из локальной актуальной версии Манифеста Пакета Обновления
          let upmData: IUpm = loadFileDataAsObject(
            this.envConfigData.DOWNLOADS_DIRECTORY_PATH,
            this.envConfigData.UPDATE_PACK_MANIFEST_FILE,
          )

          if (upmData) {
            this.mainLifeCycle(upmData)
          }
          else {
            this.logManager.warn(`No Update Packet Manifest in ${this.envConfigData.DOWNLOADS_DIRECTORY_PATH}. Please, wait for server announcement.`)
          }
        } catch (e) {
          this.errorHandler.handle(<IFotaError>e)
          if (!('_logLevel' in (e as Error))) {
            this.logManager.log2Console(501, e)
          }
          fotaEventEmitter.emit(eventNames.SYSTEM_STATUS_CHANGE, systemStatus.WAIT_MANIFEST)
        } finally {
          if (fotaEventEmitter.listenerCount(eventNames.HAS_NEW_MANIFEST, this.newManifestListener) == 0) {
            fotaEventEmitter.on(eventNames.HAS_NEW_MANIFEST, this.newManifestListener)
          }
        }
      })

      await this.kcManager.connect()

    } catch (e) {
      this.errorHandler.handle(<IFotaError>e)
      this.logManager.log2Console(112, e)
      // Имитация появления сети
      if (e instanceof NetInterfaceNotUpError ||
        e instanceof RuntimeConnectionSocketMasterError ||
        e instanceof NotAccessError ||
        e instanceof NoSocketMasterError) {
        this.interfaceNameCount += 1
        setTimeout(() => {
          this.start()
        }, 5000)
      }
    }
  }

  private async downloadUpm(wialonDataReceived: any) {

    let httpsRequestOptions: IHttpsRequestOptions | URL
    if (process.env.NODE_ENV == 'development') {
      httpsRequestOptions = {
        host: this.envConfigData.KAMAZ_CLOUD_HOST,
        port: '20901',
        path: '/manifest/update_pack_manifest.json'
      }
    }
    else {
      if (this.envConfigData.KAMAZ_CLOUD_HOST == 'fota.tmpdev.ru') {
        httpsRequestOptions = {
          host: this.envConfigData.KAMAZ_CLOUD_HOST,
          path: '/upm-encrypted-picture'
        }
      }
      else {
        httpsRequestOptions = new URL(wialonDataReceived.kamaz_cloud_upm_url)
      }
    }

    await this.upmManager.downloadUpm(httpsRequestOptions, this.envConfigData.UPDATE_PACK_MANIFEST_FILE)

    return loadFileDataAsObject(
      this.envConfigData.DOWNLOADS_DIRECTORY_PATH,
      this.envConfigData.UPDATE_PACK_MANIFEST_FILE,
    )
  }

  private checkManifest(upmData: IUpm) {
    const stats = fs.statSync(checkAbsolutePath(`${this.envConfigData.DOWNLOADS_DIRECTORY_PATH}/${this.envConfigData.UPDATE_PACK_MANIFEST_FILE}`))
    if (stats.size == 0) {
      throw new LargeSizeFilesError([this.envConfigData.UPDATE_PACK_MANIFEST_FILE])
    }
  }

  private async downloadArtifacts(upmData: IUpm) {
    this.logManager.info('/getpacket request to KAMAZ-CLOUD.')
    let httpsRequestOptions: IHttpsRequestOptions
    if (process.env.NODE_ENV == 'development') {
      httpsRequestOptions = {
        host: this.envConfigData.KAMAZ_CLOUD_HOST,
        port: '20901',
        path: "",
      }
    }
    else {
      if (this.envConfigData.KAMAZ_CLOUD_HOST == 'fota.tmpdev.ru') {
        httpsRequestOptions = {
          host: this.envConfigData.KAMAZ_CLOUD_HOST,
          path: '/upm-encrypted-picture',
        }
      }
      else {
        httpsRequestOptions = {
          host: this.envConfigData.KAMAZ_CLOUD_HOST,
          path: "",
        }
      }
    }

    await this.upmManager.downloadAndCheckArtifacts(httpsRequestOptions, upmData)

    const logLastEntryFileExists = fs.existsSync(checkAbsolutePath(`${this.envConfigData.LOGS_DIRECTORY_PATH}/${this.envConfigData.LOG_LAST_ENTRY_FILE}`))
    if (logLastEntryFileExists) {
      this.logLastEntryData = loadFileDataAsObject(
        this.envConfigData.LOGS_DIRECTORY_PATH,
        this.envConfigData.LOG_LAST_ENTRY_FILE,
      )
    }
  }

  private checkArtifacts(upmData: IUpm) {
    const resultError = {
      noExists: <string[]>[],
      largeSize: <string[]>[],
      smallSize: <string[]>[],
    }

    for (let artifact of upmData.artifacts) {
      const artifactPath = checkAbsolutePath(`${this.envConfigData.DOWNLOADS_DIRECTORY_PATH}/${artifact.file_name}`)

      if (!fs.existsSync(artifactPath)) {
        resultError.noExists.push(artifact.file_name)
        continue
      }
      const artifactStats = fs.statSync(artifactPath)
      if (artifactStats.size > artifact.file_size) {
        resultError.largeSize.push(artifact.file_name)
      }
      if (artifactStats.size < artifact.file_size) {
        resultError.smallSize.push(artifact.file_name)
      }
    }
    if (resultError.noExists.length != 0) {
      throw new NoExistsFilesError(resultError.noExists)
    }
    if (resultError.largeSize.length != 0) {
      throw new LargeSizeFilesError(resultError.largeSize)
    }
    if (resultError.smallSize.length != 0) {
      throw new SmallSizeFilesError(resultError.smallSize)
    }
  }

  private decryptArtifacts(upmData: IUpm) {
    this.cryptoManager.decryptArtifacts(upmData)
  }

}
