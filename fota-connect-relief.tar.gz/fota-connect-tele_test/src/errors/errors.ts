import {IFotaError} from './../interfaces/interfaces'
import {logLevel} from './../enums/enums'


export class CustomError extends Error implements IFotaError {
  _logLevel: logLevel
  message: string

  constructor(e: Error, logLevel_: logLevel = logLevel.ERROR) {
    super()
    this.message = e.message
    this._logLevel = logLevel_
  }
}


/** Ошибка отсутсвия сетевого интерфейса. */
export class NetInterfaceNotUpError extends Error implements IFotaError {
  _logLevel = logLevel.ERROR
  message: string

  constructor(interfaceName: string) {
    super()
    this.message = `Interface ${interfaceName} is not up.`
  }
}

/*   Ошибки с файловой системой   */

/** Ошибка прав доступа. */
export class NotAccessError extends Error implements IFotaError {
  _logLevel = logLevel.CRITICAL
  message: string

  constructor(fileName: string) {
    super()
    this.message = `No access rights to read or write the file by ${fileName}`
  }
}

/*   Ошибки с артефактами   */

/** Ошибка отсутсвие ответа от сервера во время скачивания. */
export class ArtifactDownloadInterruptedError extends Error implements IFotaError {
  _logLevel = logLevel.WARN
  message: string

  constructor(artifactName: string) {
    super()
    this.message = `No response from FOTA.Cloud. File ${artifactName} downloading interrupted.`
  }
}

/** Ошибка отсутствие файлов в локальном хранилище. */
export class NoExistsFilesError extends Error implements IFotaError {
  _logLevel = logLevel.ERROR
  message: string

  constructor(artifactName: string[]) {
    super()
    this.message = `${artifactName.length == 1? 'File': 'Files'} ${artifactName.join(', ')} no exists.`
  }
}

/** Ошибка большой размер файлов. */
export class LargeSizeFilesError extends Error implements IFotaError {
  _logLevel = logLevel.ERROR
  message: string
  constructor(artifactName: string[]) {
    super()
    this.message = `${artifactName.length == 1? 'File': 'Files'} ${artifactName.join(', ')} has large size.`
  }
}

/** Ошибка малый размер файлов. */
export class SmallSizeFilesError extends Error implements IFotaError {
  _logLevel = logLevel.ERROR
  message: string
  constructor(artifactName: string[]) {
    super()
    this.message = `${artifactName.length == 1? 'File': 'Files'} ${artifactName.join(', ')} has small size.`
  }
}

/*   Ошибки связи с клаудом   */

export class NoConnectionCloudError extends Error implements IFotaError {
  message = 'No connection to Kamaz-Cloud.'
  _logLevel = logLevel.WARN
}

export class NoAvailableUrlError extends Error implements IFotaError {
  message: string
  _logLevel = logLevel.WARN

  constructor(url: string) {
    super()
    this.message = `The URL ${url} is not available.`
  }
}

export class RuntimeConnectionCloudError extends Error implements IFotaError {
  message = 'Connection runtime to Kamaz-Cloud error.'
  _logLevel = logLevel.WARN
}

export class TimeoutConnectionCloudError extends Error implements IFotaError {
  message = 'Connection time to Kamaz-Cloud is out.'
  _logLevel = logLevel.WARN
}

/*   Ошибки связи с сокетами   */

export class NoConnectionSocketError extends Error implements IFotaError {
  message: string
  _logLevel = logLevel.WARN
  constructor(master: string) {
    super()
    this.message = `No connection to socket ${master}.`
  }
}

export class NoSocketMasterError extends Error implements IFotaError {
  _logLevel = logLevel.CRITICAL
  message: string

  constructor(master: string, subMessage: string) {
    super()
    this.message = `There is no socket for IPC with ${master}}: ${subMessage}! Emergency process termination!.`
  }
}

export class RuntimeConnectionSocketMasterError extends Error implements IFotaError {
  _logLevel = logLevel.CRITICAL
  message: string

  constructor(master: string, subMessage: string) {
    super()
    this.message = `There is no connection to ${master}: ${subMessage}! Emergency process termination!.`
  }
}

export class CloseConnectionSocketMasterError extends Error implements IFotaError {
  _logLevel = logLevel.CRITICAL
  message: string

  constructor(master: string) {
    super()
    this.message = `IPC socket connection has been closed by ${master}.`
  }
}
