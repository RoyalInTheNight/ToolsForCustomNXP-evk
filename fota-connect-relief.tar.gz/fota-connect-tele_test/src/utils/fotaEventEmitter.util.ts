/**
 * EventEmitter в приложении
 */
import { EventEmitter } from 'node:events'

export const fotaEventEmitter = new EventEmitter()

// const fotaEventEmitter = new EventEmitter()
// export default fotaEventEmitter
