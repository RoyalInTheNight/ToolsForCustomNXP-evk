import fs from 'fs'

export function checkAndMakeDir(path: string) {
  // this.logManager.log2Console(['Check path ', path])
  const directoryExists = fs.existsSync(path)
  // this.logManager.log2Console(['Exists path ', path, configsDirectoryExists])
  if (!directoryExists) {
    // this.logManager.log2Console(['Make path ', path])
    fs.mkdirSync(path)
  }
  return path
}