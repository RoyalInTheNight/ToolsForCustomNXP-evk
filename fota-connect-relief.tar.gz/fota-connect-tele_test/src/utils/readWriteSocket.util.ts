import net from "node:net";

export function readFromSocket(data: Buffer){
    const dataDecoded = decodeURIComponent(String.fromCharCode(...data)) // data: <Uint8Array>
    const dataDecodedParsed = JSON.parse(dataDecoded)
    return dataDecodedParsed
}

export function writeToSocket(socket: net.Socket, data: any, delay: number = 1){
    const dataUint8Array = new TextEncoder().encode(JSON.stringify(data))
    setTimeout(()=>socket.write(dataUint8Array), delay)
}