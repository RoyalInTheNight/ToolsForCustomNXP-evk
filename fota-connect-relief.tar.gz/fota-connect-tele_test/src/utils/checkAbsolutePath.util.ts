import path from 'path'

/**
 * Функция проверяет путь полученный в аргументе.
 * Если путь абсолютный, функция возвращает его, иначе добавляет текущую рабочую директорию.
 * */
export function checkAbsolutePath(_path: string) {
  const s = path.isAbsolute(_path) ? _path : path.join(process.cwd(), _path)
  return s
}