/**
 * KcManager работает с KAMAZ-CLOUD
 */
import {EventEmitter} from 'node:stream'
import net from 'node:net'
import Tls from 'tls'
import {eventNames, mPacketTitles, systemStatus} from './../enums/enums'
import {ErrorHandler, LogManager, SystemStatusManager} from '.'

import {crc16calculator, fotaEventEmitter} from '../utils'
import {CustomError, NoConnectionCloudError, TimeoutConnectionCloudError} from '../errors/errors'
import {IFotaError, IMPacketMessage} from '../interfaces/interfaces'

export class KcManager {
  private static instance: KcManager

  private readonly socket: net.Socket
  private client: net.Socket | null // TODO: сделать readonly после первой записи
  private readonly fotaEventEmitter: EventEmitter

  private readonly blockLogin: string
  private readonly kcHost: string
  private readonly kcPort: number
  private readonly logManager: LogManager
  private readonly systemStatusManager: SystemStatusManager
  private readonly errorHandler: ErrorHandler

  private readonly wialonDataReceived = <any>{}

  private pingStatus = {
    isReceived: false,
    pingCount: 0,
  }

  private listeners: { [key: string]: { has: boolean, func: any } }
  private isClose = false
  private connectInit = false

  private constructor(config: { [key: string]: any }) {
    this.blockLogin = config.blockLogin
    this.kcHost = config.kcHost
    this.kcPort = config.kcPort
    this.logManager = config.logManager
    this.systemStatusManager = config.systemStatusManager
    this.errorHandler = config.errorHandler

    this.socket = new net.Socket()
    this.client = null
    this.fotaEventEmitter = fotaEventEmitter
    this.listeners = {
      connect: {
        has: false,
        func: this.connectListener,
      },
      close: {
        has: false,
        func: this.closeListener,
      },
      data: {
        has: false,
        func: this.dataListener,
      },
      error: {
        has: false,
        func: this.errorListener,
      },
      timeout: {
        has: false,
        func: this.timeoutListener,
      },
    }
  }

  /**
   * Метод получения экземпляра класса KcManager
   * @param kcIp — IP-адрес Kc
   * @param kcPort — порт Kc
   * @param logManager — экземпляр класса LogManager
   */
  static getInstance = (config: { [key: string]: any }): KcManager => {
    if (!KcManager.instance) {
      KcManager.instance = new KcManager(config)
    }
    return KcManager.instance
  }

  private reconnect = () => {
    if (this.systemStatusManager.systemStatus != systemStatus.WAIT_CONNECTION) {
      return
    }
    setTimeout(() => {
      if (this.client!.destroyed) {
        this.connect( )
            .catch(e => {
              throw new CustomError(e as Error)
            })
      }
    }, 5000)
  }

  private connectListener = async () => {
    this.logManager.info('Connected to KAMAZ-CLOUD successfully.')
    await this._login(this.blockLogin)
  }
  private dataListener = (data: Buffer) => {
    if (data.toString()
            .startsWith('#A')) {
      this.handleAPacket(data.toString())
    }
    else {
      this.handleMPacket(data.toString())
    }
  }
  private errorListener = async (e: Error) => {
    try {
      this.fotaEventEmitter.emit(eventNames.SYSTEM_STATUS_CHANGE, systemStatus.WAIT_CONNECTION)

      // this.reconnect()
      if ('code' in e) {
        switch (e.code) {
          case 'ECONNREFUSED': {
            throw new NoConnectionCloudError()
            break
          }
          default: {
            this.logManager.log2Console('errorListener', e)
            this.client!.destroy()
            throw new CustomError(e)
          }
        }
      }
      else {
        this.logManager.log2Console('errorListener', e)
        this.client!.destroy()
        throw new CustomError(e)
      }

      if (this.kcHost == '158.160.43.238' && e.message == `getaddrinfo ENOTFOUND ${this.kcHost}`) {
        this.logManager.warn('No internet connection.')
      }
    } catch (e) {
      this.errorHandler.handle(e as IFotaError)
    }
  }
  private closeListener = () => {
    this.fotaEventEmitter.emit(eventNames.SYSTEM_STATUS_CHANGE, systemStatus.WAIT_CONNECTION)
    this.isClose = true
    this.reconnect()
  }
  private timeoutListener = () => {
    this.fotaEventEmitter.emit(eventNames.SYSTEM_STATUS_CHANGE, systemStatus.WAIT_CONNECTION)
    this.client!.destroy()
    this.errorHandler.handle(new TimeoutConnectionCloudError())
  }
  private sigintListener = () => {
    this.logManager.debug('\nCaught interrupt signal: shutting down FOTA.Connect.')
    this.client!.unref() // ? TODO: или надо это вешать на this.kcSocket ?
    // ? TODO: this.kcSocketClient.end() ?
    process.exit(0)
  }

  /**
   * Установка соединения с KAMAZ-CLOUD (Telemetryd)
   //  * @param kcIp - IP KAMAZ-CLOUD (Telemetryd)
   //  * @param kcPort - PORT KAMAZ-CLOUD (Telemetryd)
   */
  connect = ( ): Promise<any> => { // TODO: TS
    return new Promise((resolve, reject) => {
      this.logManager.info('Try to internet connection.')
      this.isClose = false

      if (this.client == null) this.client = this.socket
      if (process.env.NODE_ENV == 'development') {
        this.client.connect({port: this.kcPort, host: this.kcHost})
      }
      else {
        if (this.kcHost == 'fota.tmpdev.ru') {
          this.client.connect({port: 20251, host: '158.160.43.238'})
        }
        else {
          this.client.connect({port: this.kcPort, host: this.kcHost})
        }
      }

      for (let key of Object.keys(this.listeners)) {
        if (!this.listeners[key].has) {
          this.client.addListener(key, this.listeners[key].func)
          this.listeners[key].has = true
        }
      }

      this.client.setTimeout(20000)

      resolve('ok')
    })
      .catch((e) => {
        if (!('_logLevel' in (e as Error))) {
          this.logManager.log2Console('connect e ', (e as Error))
        }
        throw new CustomError(e as Error, (e as IFotaError)._logLevel)
      })
  }

  /**
   * Авторизация в KAMAZ-CLOUD
   * @param blockLogin — login блока
   */
  _login = (blockLogin: string): Promise<any> => {
    return new Promise((resolve, reject) => {
      const connectionSubString = `2.0;${blockLogin};NA;`
      const connectionSubStringCrc16 = crc16calculator(connectionSubString)
        .toString(16)
      const connectionString = `#L#2.0;${blockLogin};NA;${connectionSubStringCrc16}\r\n`
      this.logManager.info(connectionString)
      this.client!.write(connectionString)
      this.pingStatus.isReceived = true
      this.pingStatus.pingCount = 0
      resolve('ok')
    })
      .catch(e => {
        if (!('_logLevel' in (e as Error))) {
          this.logManager.log2Console('_login e ', (e as Error))
        }
        throw new CustomError(e as Error)
      })
  }

  /**
   * Обработка #A*# пакета
   * */
  private handleAPacket = (data: string) => {
    this.logManager.log2Console(116, `Пакет ответа: ${data.toString()}\r\n`)
    if (data.trim() == '#AP#') {
      this.pingStatus.isReceived = true
      this.pingStatus.pingCount = 0
    }
    if (data.trim() == '#AL#1') {
      this.logManager.info('Login to KAMAZ-CLOUD successfully.')
      // this.fotaEventEmitter.emit(eventNames.CONNECTION_READY)
      // TODO: Пинг сервера (см реализацию ниже)
      this.pingServer()

      //Подписка на получение NMEA данных от TeleManager

      if (fotaEventEmitter.listenerCount(eventNames.GPS_DATA_RECEIVED) == 0) {
        fotaEventEmitter.on(eventNames.GPS_DATA_RECEIVED, (nmeaData: string) => {
          const wialonData = this.nmea2wialon(nmeaData)
          this.logManager.info(`${wialonData}\r\n`)
          this.client!.write(`${wialonData}\r\n`)
        })
      }

      if (fotaEventEmitter.listenerCount(eventNames.FIRMWARE_INSTALLATION_STATUS_DONE) == 0) {
        fotaEventEmitter.on(eventNames.FIRMWARE_INSTALLATION_STATUS_DONE, () => {
          this.sendMPacket({title: mPacketTitles.FOTA_REPORT, message: 'Firmware installation status send: done.'})
        })
      }

      if (fotaEventEmitter.listenerCount(eventNames.FIRMWARE_INSTALLATION_STATUS_ERROR) == 0) {
        fotaEventEmitter.on(eventNames.FIRMWARE_INSTALLATION_STATUS_ERROR, () => {
          this.sendMPacket({title: mPacketTitles.FOTA_REPORT, message: 'Firmware installation status send: error.'})
        })
      }

      if (fotaEventEmitter.listenerCount(eventNames.SEND_MESSAGE_TO_CLOUD) == 0) {
        fotaEventEmitter.on(eventNames.SEND_MESSAGE_TO_CLOUD, (payload: IMPacketMessage) => {
          this.sendMPacket(payload)
        })
      }

      this.fotaEventEmitter.emit(eventNames.CONNECTION_READY)
    }
  }

  /**
   * Обработка #M#-пакета
   * */
  private handleMPacket = (data: string) => {
    if (data) {
      this.fotaEventEmitter.emit(eventNames.WIALON_DATA_RECEIVED, data)
    }

    // Парсинг по регулярному выражению
    if (data.startsWith('#M#fota_link:')) {
      const linkStartPos = data.indexOf(':') + 1
      const linkEndPos = data.indexOf(';')
      const manifestLinkParsed = data.slice(linkStartPos, linkEndPos)
      this.wialonDataReceived['kamaz_cloud_upm_url'] = manifestLinkParsed
      this.fotaEventEmitter.emit(eventNames.HAS_NEW_MANIFEST, this.wialonDataReceived)
    }
    // if (data.toString().match(RegExArtifactLink)) {
    //   this.logManager.log2Console(286, data)
    //   const linkStartPos = data.indexOf(':') + 1
    //   const linkEndPos = data.indexOf(';')
    //   const manifestLinkParsed = data.slice(linkStartPos, linkEndPos)
    //   this.wialonDataReceived['kamaz_cloud_upm_url'] = manifestLinkParsed
    //   this.fotaEventEmitter.emit(eventNames.HAS_NEW_MANIFEST, this.wialonDataReceived)
    // }
    // if (data.length > 5 && data.includes('/manifests/')) {
    //   this.logManager.log2Console(287, data)
    //   const linkStartPos = data.indexOf(':') + 1
    //   const linkEndPos = data.indexOf(';')
    //   const manifestLinkParsed = data.slice(linkStartPos, linkEndPos)
    //
    //   this.wialonDataReceived['kamaz_cloud_upm_url'] = manifestLinkParsed
    // }
  }

  /**
   * Периодическая отправка пакета для поддержания активного TCP-соединения с сервером
   * и проверки работоспособности канала
   */
  pingServer = () => {
    if (this.isClose) {
      return
    }
    try {
      if (this.pingStatus.pingCount > 2) {
        throw new TimeoutConnectionCloudError()
      }
      if (this.pingStatus.isReceived) {
        this.pingStatus.isReceived = false
        this.client!.write('#P#\r\n')
        this.logManager.info('Ping packet sent.\r\n')
      }
      else {
        this.pingStatus.isReceived = false
        this.pingStatus.pingCount += 1
        this.client!.write('#P#\r\n')
        this.logManager.info('Ping packet sent.\r\n')
      }
      setTimeout(this.pingServer, 5000)
    } catch (e) {
      // this.errorHandler.handle(e as IFotaError)
      this.timeoutListener()
    }

  }

  private sendMPacket = (payload: IMPacketMessage) => {
    if (this.systemStatusManager.systemStatus == systemStatus.WAIT_CONNECTION) {
      return
    }
    let message = `${payload.title};${payload.message};`
    const messageSubStringCrc16 = crc16calculator(message)
      .toString(16)
    const messageString = `#M#${message}${messageSubStringCrc16}\r\n`
    this.client!.write(messageString)

    this.logManager.info(`M-Packet ${messageString} sent: done.\r\n`)
  }

  private nmea2wialon = (nmeaMessage: string): string => {
    const nmeaIndexes = {
      source: 0,//Идентификатор источника
      time: 1,//Время фиксации местоположения по UTC
      status: 2,//Статус. А - достоверны, V - недостоверны
      latitude: 3,//Широта
      latitudeNS: 4,//N - северная широта, S - южная широта
      longitude: 5,//Долгота
      longitudeEW: 6,//Е - восточная долгота, W - западная долгота
      vv: 7,//Горизонтальная составляющая скорости в узлах
      bb: 8,//Путевой угол(направление скорости) в градусах
      date: 9,//Дата
      xx: 10,//Магнитное склонение в градусах
      n: 11,//Направление магнитного склонения: для получения магнитного курса магнитное склонение необходимо «E» —
            // вычесть, «W» — прибавить к истинному курсу.
      m: 12,//Индикатор режима: «A» — автономный, «D» — дифференциальный, «E» — аппроксимация, «N» — недостоверные
            // данные (часто отсутствует, данное поле включая запятую отсутствует в старых версиях NMEA).
      hh: 13,//Контрольная сумма.
    }
    const wialonIndexes = {
      date: 0,
      time: 1,
      lat1: 2,
      lat2: 3,
      lon1: 4,
      lon2: 5,
      speed: 6,
      course: 7,
      alt: 8,
      sats: 9,
      hdop: 10,
      inputs: 11,
      outputs: 12,
      adc: 13,
      iButton: 14,
      params: 15,
      crc16: 16,
    }

    const wialonData: string[] = ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', '', 'NA', '']
    const nmea = nmeaMessage.split(',')
    wialonData[wialonIndexes.date] = nmea[nmeaIndexes.date]
    wialonData[wialonIndexes.time] = nmea[nmeaIndexes.time].split('.')[0]
    wialonData[wialonIndexes.lat1] = nmea[nmeaIndexes.latitude]
    wialonData[wialonIndexes.lat2] = nmea[nmeaIndexes.latitudeNS]
    wialonData[wialonIndexes.lon1] = nmea[nmeaIndexes.longitude]
    wialonData[wialonIndexes.lon2] = nmea[nmeaIndexes.longitudeEW]
    wialonData[wialonIndexes.speed] = `${Math.round(parseFloat(nmea[nmeaIndexes.vv]) * 2 * 0.9)}`
    wialonData[wialonIndexes.course] = `${Math.round(parseFloat(nmea[nmeaIndexes.bb]))}`

    const wialonDataSubstring = `${wialonData.slice(0, wialonData.length)
                                             .join(';')};`
    const wialonSubStringCrc16 = crc16calculator(wialonDataSubstring)
      .toString(16)
    const res = `#D#${wialonDataSubstring}${wialonSubStringCrc16}`
    return res
  }

}
