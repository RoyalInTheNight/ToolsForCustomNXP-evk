import {checkAbsolutePath} from "../utils";
import fs from "fs";
import {IUpm} from "../interfaces/interfaces";
import {LogManager} from "./LogManager";
import {fotaEventEmitter} from "../utils";
import {eventNames, mPacketTitles} from "../enums/enums";


export class Reporter {

  private static instance: Reporter

  private intervalId: NodeJS.Timeout | undefined
  private logManager: LogManager

  private constructor(logManager: LogManager) {
    this.logManager = logManager
  }

  public static getInstance = (logManager: LogManager) => {
    if (!Reporter.instance) {
      Reporter.instance = new Reporter(logManager)
    }
    return Reporter.instance
  }

  public getTemplate = (upm: IUpm, stage: string) => {
    return {
      packet_id: upm.packet_id,
      version: upm.version,
      stage: stage,
      status: 'proccess',
      artifacts: upm.artifacts.map(artifact => {
        return {
          artifact_id: artifact.artifact_id,
          file_name: artifact.file_name,
          type: artifact.type,
          status: 'wait'
        }
      })
    }
  }

  public startReported = (path: string) => {
    let message = fs.readFileSync(checkAbsolutePath(path))
                    .toString();
    fotaEventEmitter.emit(eventNames.SEND_MESSAGE_TO_CLOUD, {title: mPacketTitles.FOTA_REPORT, message: message})
    this.intervalId = setTimeout(() => this.startReported(path), 5000)
  }

  public stopReported = (path: string) => {
    let message = fs.readFileSync(checkAbsolutePath(path))
                    .toString();
    fotaEventEmitter.emit(eventNames.SEND_MESSAGE_TO_CLOUD, {title: mPacketTitles.FOTA_REPORT, message: message})
    clearTimeout(this.intervalId!)
  }

}