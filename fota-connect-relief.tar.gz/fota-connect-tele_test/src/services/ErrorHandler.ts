import {IFotaError} from '../interfaces/interfaces';
import {eventNames} from '../enums/enums';
import {LogManager} from '.';
import {fotaEventEmitter} from './../utils';


class ErrorHandler {
  private static instance: ErrorHandler

  private logFunctions: { [key: string]: (mes: string) => void } = {
    'debug': (mes: string) => this.logManager.debug(mes),
    'info': (mes: string) => this.logManager.info(mes),
    'warn': (mes: string) => this.logManager.warn(mes),
    'error': (mes: string) => this.logManager.error(mes),
    'critical': (mes: string) => this.logManager.critical(mes)
  }

  private constructor(
    private readonly logManager: LogManager
  ) {
    fotaEventEmitter.on(eventNames.HANDLE_ERROR, (error: IFotaError) => this.handle(error))
  }

  public static getInstance(
    logManager: LogManager
  ): ErrorHandler {
    if (!ErrorHandler.instance) {
      ErrorHandler.instance = new ErrorHandler(logManager)
    }
    return ErrorHandler.instance
  }

  public handle(error: IFotaError) {
    if (error == undefined || error._logLevel == undefined || error.message == undefined) return
    this.logFunctions[error._logLevel](error.message)
  }

}

export {
  ErrorHandler,
}
