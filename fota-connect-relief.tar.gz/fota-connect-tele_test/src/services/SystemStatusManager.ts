import { fotaEventEmitter } from '../utils'
import { eventNames, systemStatus } from '../enums/enums'
import { LogManager } from './LogManager'

class SystemStatusManager {

  private static instance: SystemStatusManager
  private _systemStatus: systemStatus = systemStatus.APP_START

  private constructor(
    sysStatus: systemStatus,
    private readonly logManager: LogManager,
  ) {
    this.systemStatus = sysStatus
    fotaEventEmitter.on(eventNames.SYSTEM_STATUS_CHANGE, (status: systemStatus) => {
      //Необходимо рассмотреть важность статусов, чтоб их нельзя было менять как перчатки
      this.systemStatus = status
    })
  }

  set systemStatus(value: systemStatus) {
    if (this.systemStatus === value) return
    this.logManager.info(`System status change ${value}`)
    this._systemStatus = value
  }

  get systemStatus(): systemStatus {
    return this._systemStatus
  }

  public static getInstance(sysStatus: systemStatus, logManager: LogManager): SystemStatusManager {
    if (!SystemStatusManager.instance) {
      SystemStatusManager.instance = new SystemStatusManager(sysStatus, logManager)
    }
    return SystemStatusManager.instance
  }
}

export {
  SystemStatusManager,
}