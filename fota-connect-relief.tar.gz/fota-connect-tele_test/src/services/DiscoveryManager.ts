import fs from 'fs'
import { checkAbsolutePath, checkAndMakeDir, crc16calculator, fotaEventEmitter } from '../utils'
import { eventNames, mPacketTitles } from '../enums/enums'
import { CryptoManager } from './CryptoManager'

class DiscoveryManager {
  private static instance: DiscoveryManager

  private constructor(
    private readonly publicPemPath: string,
    private readonly timeDelay: number,
    private readonly cryptoManager: CryptoManager,
  ) {
    this.sendDiscovery()
  }

  /**
   * Метод получения экземпляра класса DiscoveryManager
   */
  public static getInstance(
    publicPemPath: string,
    timeDelay: number,
    cryptoManager: CryptoManager,
  ): DiscoveryManager {
    if (!DiscoveryManager.instance) {
      DiscoveryManager.instance = new DiscoveryManager(publicPemPath, timeDelay, cryptoManager)
    }
    return DiscoveryManager.instance
  }

  sendDiscovery = () => {
    const vehicleManifest = this.readDiscobery()
    //Зашифровать манифест
    const vehicleManifestEncrypt = this.cryptoManager.encrypt(vehicleManifest)
    fotaEventEmitter.emit(eventNames.SEND_MESSAGE_TO_CLOUD, {
      title: mPacketTitles.CAR_MANIFEST,
      message: vehicleManifestEncrypt,
    })
    setTimeout(() => this.sendDiscovery(), this.timeDelay)
  }

  readDiscobery = () => {

    const pubPem = fs.readFileSync(checkAbsolutePath(this.publicPemPath)).toString()

    let disoveryManifest = {
      "vin": "Z94K241BBMR228906",
      "block_login": "113011301130",
      "last_updated_ts": 1690528110,
      "block_hardware_revision": "1.2.0",
      "block_linux_version":     "0.1.0",
      "block_firmware_version":  "0.1.0",
      "block_software_version":  "0.1.0",
      "devices": [
        {
          "files": [
            "KCBCU015070001clb-01.01.0.1.s19",
            "BCU_script_binary_golang",
          ],
          "can": "can_1",
          "update_mode": "<ota, offline>",
          "last_updated_ts": 1690528110
        }
      ],
      'public_key': pubPem,
      'hashsum':''
    }

    disoveryManifest['hashsum'] = crc16calculator(JSON.stringify(disoveryManifest)).toString(16)

    return JSON.stringify(disoveryManifest)
  }
}

export {
  DiscoveryManager,
}