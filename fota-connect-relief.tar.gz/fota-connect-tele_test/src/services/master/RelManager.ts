/**
 * RelManager работает с REL.Master
 */
// ? TODO: принимать информацию из CAN или relief_master.js emulator по сокету
class RelManager {
  
}

export {
  RelManager
}
