import net from 'node:net'

import {ErrorHandler, LogManager} from '..'

import {checkAbsolutePath, fotaEventEmitter} from '../../utils'
import {eventNames, logLevel, mPacketTitles} from '../../enums/enums'
import {
  CloseConnectionSocketMasterError,
  CustomError,
  NoConnectionSocketError,
  NoSocketMasterError,
  NotAccessError,
} from '../../errors/errors'
import {IMPacketMessage} from "../../interfaces/interfaces";

/**
 * TeleManager работает с TELE.Master
 */
export class TeleManager {
  private static instance: TeleManager

  private teleIpcClient: net.Socket | undefined

  private readonly masterName = 'TELE.Master'

  private listeners: { [key: string]: { has: boolean, func: any } }

  private isConnect = false

  private constructor(
    private readonly teleIpcSocketPath: string,
    private readonly logManager: LogManager,
    private readonly errorHandler: ErrorHandler,
    private readonly teleMasterIpcSignals: any = {},
    // private teleStartIpcSignal: Buffer // ? boolean
  ) {
    this.listeners = {
      connect: {
        has: false,
        func: this.connectListener
      },
      close: {
        has: false,
        func: this.closeListener,
      },
      data: {
        has: false,
        func: this.dataListener,
      },
      error: {
        has: false,
        func: this.errorListener,
      }
    }
  }

  /**
   * Метод получения экземпляра класса TeleManager
   * @param teleIpcSocketPath — путь до IPC сокета, создаваемого TELE.Master
   * @param logManager - экземпляр класса LogManager
   */
  public static getInstance(
    teleIpcSocketPath: string,
    logManager: LogManager,
    errorHandler: ErrorHandler,
  ): TeleManager {
    if (!TeleManager.instance) {
      TeleManager.instance = new TeleManager(teleIpcSocketPath, logManager, errorHandler)
    }
    return TeleManager.instance
  }

  private reconnect = () => {
    setTimeout(() => {
      // if (this.teleIpcClient!.destroyed) {
      for (let key of Object.keys(this.listeners)) {
        if (this.listeners[key].has) {
          this.teleIpcClient!.removeListener(key, this.listeners[key].func)
          this.listeners[key].has = false
        }
      }
      this.teleIpcClient = undefined
      this.start()
          .catch(e => {
            this.errorHandler.handle(new CustomError(e as Error))
          })
      // }
    }, 5000)
  }

  private connectListener = () => {
    this.logManager.info('Connected to TELE.Master successfully.')
    // this.teleMasterIpcSignals['TELE.Start'] = Buffer.from([1]) // Устанавливает TELE.Start === 1 (true)
    // writeToSocket(this.teleIpcClient!, this.teleMasterIpcSignals, 1)
  }
  private errorListener = (e: Error) => {
    if ('code' in e) {
      switch (e.code) {
        case 'EACCES': {
          this.errorHandler.handle(new NotAccessError(this.teleIpcSocketPath))
          break
        }
        case 'ENOENT': {
          this.errorHandler.handle(new NoSocketMasterError(this.masterName, (e as Error).message))
          break
        }
        case 'ECONNREFUSED': {
          this.errorHandler.handle(new NoConnectionSocketError(this.masterName))
          break
        }
        default : {
          this.logManager.log2Console(110, e)
          this.errorHandler.handle(new CustomError(e, logLevel.CRITICAL))
        }
      }
    }
    else {
      this.logManager.log2Console(110, e)
      this.errorHandler.handle(new CustomError(e, logLevel.CRITICAL))
    }
    this.teleIpcClient!.destroy()
  }
  private closeListener = () => {
    this.isConnect = false
    this.errorHandler.handle(new CloseConnectionSocketMasterError(this.masterName))
    this.reconnect()

    // ? TODO: что делать в случае, если TELE.Master вдруг закрывает соединение?
    // TODO: можно попробовать в App глобальную переменную типа isDownloadActive
  }
  private dataListener = (data: Buffer) => {
    this.logManager.log2Console(74, data.toString())
    try {


      if (data.toString()
              .includes('RMC')) {
        fotaEventEmitter.emit(eventNames.GPS_DATA_RECEIVED, data.toString())
      }
      else {
        fotaEventEmitter.emit(eventNames.SEND_MESSAGE_TO_CLOUD, <IMPacketMessage>{
          message: data.toString(),
          title: mPacketTitles.TELE_TEST
        })
      }

      // const dataDecodedParsed = readFromSocket(data) // { 'TELE.Finish': { type: 'Buffer', data: [ 1 ] } }
      // if (dataDecodedParsed['TELE.Finish'].data[0] === 0) { // Если TELE.Finish === 0 (false)
      //   this.teleMasterIpcSignals['TELE.Start'] = Buffer.from([0])
      //   writeToSocket(this.teleIpcClient!, this.teleMasterIpcSignals, 500)
      // }
      // else if (dataDecodedParsed['TELE.Finish'].data[0] === 1) {
      //   if ('TELE.Buf' in dataDecodedParsed) {
      //     const nmeaData = Buffer.from(dataDecodedParsed['TELE.Buf']['data']).toString()
      //     fotaEventEmitter.emit(eventNames.GPS_DATA_RECEIVED, nmeaData)
      //   }
      //   this.teleMasterIpcSignals['TELE.Start'] = Buffer.from([1])
      //   writeToSocket(this.teleIpcClient!, this.teleMasterIpcSignals, 500)
      // }
    } catch (e) {
      fotaEventEmitter.emit(eventNames.HANDLE_ERROR, new CustomError(e as Error))
    }

  }

  public start = async () => {
    this.teleIpcClient = net.createConnection(checkAbsolutePath(this.teleIpcSocketPath))

    for (let key of Object.keys(this.listeners)) {
      if (!this.listeners[key].has) {
        this.teleIpcClient.addListener(key, this.listeners[key].func)
        this.listeners[key].has = true
      }
    }
  }
}
