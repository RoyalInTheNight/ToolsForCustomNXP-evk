import net from 'node:net'
import fs from 'node:fs'

import { ErrorHandler, LogManager } from '..'

import { IFotaError, IFotaMasterIpcSignals } from '../../interfaces/interfaces'
import { eventNames, logLevel, systemStatus } from './../../enums/enums'
import { checkAbsolutePath, fotaEventEmitter, readFromSocket, writeToSocket } from '../../utils'
import {
  CloseConnectionSocketMasterError,
  CustomError, NoConnectionSocketError,
  NoExistsFilesError,
  NoSocketMasterError,
  NotAccessError,
  RuntimeConnectionSocketMasterError,
} from '../../errors/errors'


/**
 * FotaManager работает с FOTA.Master
 */
export class FotaManager {
  private static instance: FotaManager
  private readonly fotaMasterIpcSignals = <IFotaMasterIpcSignals>{}
  private fotaIpcClient: net.Socket | undefined

  private readonly masterName = 'FOTA.Master'

  private listeners: { [key: string]: { has: boolean, func: any } }

  private wasFotaStartSignal = false
  private isConnect = false

  private constructor(
    private readonly workingPath: string,
    private readonly fotaIpcSocketPath: string,
    private readonly logManager: LogManager,
    private readonly errorHandler: ErrorHandler,
  ) {
    this.listeners = {
      connect: {
        has: false,
        func: this.connectListener,
      },
      close: {
        has: false,
        func: this.closeListener,
      },
      data: {
        has: false,
        func: this.dataListener,
      },
      error: {
        has: false,
        func: this.errorListener,
      },
    }

    fotaEventEmitter.on(eventNames.ARTIFACTS_IS_READY, () => {
      if (this.isConnect) {
        this.wasFotaStartSignal = false
        this.fotaMasterIpcSignals['FOTA.Start'] = Buffer.from([1]) // Устанавливает 'FOTA.Start === 1 (true)
        writeToSocket(this.fotaIpcClient!, this.fotaMasterIpcSignals)
        fotaEventEmitter.emit(eventNames.SYSTEM_STATUS_CHANGE, systemStatus.ARTIFACT_INSTALLATION)
      }
      else {
        this.wasFotaStartSignal = true
      }
    })
  }

  /**
   * Метод получения экземпляра класса FotaManager
   * @param fotaIpcSocketPath — путь до IPC сокета, создаваемого FOTA.Master
   * @param logManager - экземпляр класса LogManager
   */
  public static getInstance(
    workingPath: string,
    fotaIpcSocketPath: string,
    logManager: LogManager,
    errorHandler: ErrorHandler,
  ): FotaManager {
    if (!FotaManager.instance) {
      FotaManager.instance = new FotaManager(workingPath, fotaIpcSocketPath, logManager, errorHandler)
    }
    return FotaManager.instance
  }


  private reconnect = () => {
    setTimeout(() => {
      // if (this.fotaIpcClient!.destroyed) {
      for (let key of Object.keys(this.listeners)) {
        if (this.listeners[key].has) {
          this.fotaIpcClient!.removeListener(key, this.listeners[key].func)
          this.listeners[key].has = false
        }
      }
      this.fotaIpcClient = undefined
      this.start()
        .catch(e => {
          this.errorHandler.handle(new CustomError(e as Error))
        })
      // }
    }, 5000)
  }

  private connectListener = () => {
    this.isConnect = true
    this.logManager.info('Connected to FOTA.Master successfully.')
    if (this.wasFotaStartSignal) {
      fotaEventEmitter.emit(eventNames.ARTIFACTS_IS_READY)
    }
  }
  private dataListener = (data: Buffer) => {
    try {
      const dataDecodedParsed = readFromSocket(data) // { 'FOTA.Finish': { type: 'Buffer', data: [ 0 ] } }
      this.logManager.log2Console(77, 'fota_master.js emulator: ', dataDecodedParsed)

      if (dataDecodedParsed['FOTA.Finish'].data[0] === 0) { // Если сброшен FOTA.Finish (FOTA.Finish === 0 (false))
        this.fotaMasterIpcSignals['FOTA.Start'] = Buffer.from([0]) // Сбрасывает FOTA.Start (FOTA.Start === 0 (false))
        writeToSocket(this.fotaIpcClient!, this.fotaMasterIpcSignals)
      }
      else if (dataDecodedParsed['FOTA.Finish'].data[0] === 1) { // Если установлен FOTA.Finish (FOTA.Finish === 1 (true))
        // TODO: окружение
        const fmrPath = checkAbsolutePath(`${this.workingPath}/fota_master_result.json`)
        if (!fs.existsSync(fmrPath)) {
          throw new NoExistsFilesError(['fota_master_result.json'])
        }

        const fotaMasterResultFileDataParsed = JSON.parse(fs.readFileSync(fmrPath).toString())
        let isSuccess = true
        for (let artifactResult of fotaMasterResultFileDataParsed) {
          isSuccess = isSuccess && artifactResult.flashing_status_code != 2
        }
        if (isSuccess) {
          this.logManager.info('Firmware installation: done.')
          fotaEventEmitter.emit(eventNames.SYSTEM_STATUS_CHANGE, systemStatus.WAIT_MANIFEST)
          fotaEventEmitter.emit(eventNames.FIRMWARE_INSTALLATION_STATUS_DONE)
        }
        else {
          this.logManager.info('Firmware installation: error.')
          fotaEventEmitter.emit(eventNames.SYSTEM_STATUS_CHANGE, systemStatus.WAIT_MANIFEST)
          fotaEventEmitter.emit(eventNames.FIRMWARE_INSTALLATION_STATUS_ERROR)
        }
        for (let fileName of fs.readdirSync(checkAbsolutePath(this.workingPath))) {
          fs.rmSync(checkAbsolutePath(`${this.workingPath}/${fileName}`), {
            recursive: true,
            force: true,
          })
        }
      }
    }
    catch (e) {
      fotaEventEmitter.emit(eventNames.HANDLE_ERROR, <IFotaError>e)
      fotaEventEmitter.emit(eventNames.SYSTEM_STATUS_CHANGE, systemStatus.WAIT_MANIFEST)
    }
  }
  private closeListener = () => {
    this.isConnect = false
    this.errorHandler.handle(new CloseConnectionSocketMasterError(this.masterName))
    this.reconnect()
  }
  private errorListener = (e: Error) => {
    if ('code' in e) {
      switch (e.code) {
        case 'EACCES': {
          this.errorHandler.handle(new NotAccessError(this.fotaIpcSocketPath))
          break
        }
        case 'ENOENT': {
          this.errorHandler.handle(new NoSocketMasterError(this.masterName, (e as Error).message))
          break
        }
        case 'ECONNREFUSED': {
          this.errorHandler.handle(new NoConnectionSocketError(this.masterName))
          break
        }
        default : {
          this.logManager.log2Console(110, e)
          this.errorHandler.handle(new CustomError(e, logLevel.CRITICAL))
        }
      }
    }
    else {
      this.logManager.log2Console(110, e)
      this.errorHandler.handle(new CustomError(e, logLevel.CRITICAL))
    }
    this.fotaIpcClient!.destroy()
  }

  public start = () => {
    return new Promise((resolve, reject) => {
      this.fotaIpcClient = net.createConnection(checkAbsolutePath(this.fotaIpcSocketPath))

      for (let key of Object.keys(this.listeners)) {
        if (!this.listeners[key].has) {
          this.fotaIpcClient.addListener(key, this.listeners[key].func)
          this.listeners[key].has = true
        }
      }
      resolve('ok')
    })
  }
}
