/**
 * UpmManager работает с манифестом пакета обновления (далее — манифест)
 */
import crypto from 'node:crypto'
import fs, {WriteStream} from 'node:fs'
import https from 'node:https'
import http from 'node:http'
import path from "path";

import {LogManager, Reporter} from '.'
import {
  ArtifactTypes,
  eventNames,
  firmwareStatusDownload,
} from './../enums/enums'
import {checkAbsolutePath, fotaEventEmitter} from '../utils'

import {
  IUpm,
  IArtifactUpm,
  IArtifactLocal,
  IArtifactDownloadStatus,
  IHttpsRequestOptions,
  IFotaError, IReport,
} from '../interfaces/interfaces'
import {
  ArtifactDownloadInterruptedError,
  CustomError, NoAvailableUrlError, NoConnectionCloudError,
} from '../errors/errors'


export class UpmManager {
  private static instance: UpmManager

  private downloadReport: string

  private report: IReport = <IReport>{}

  private constructor(
    readonly downloadsDirectoryPath: string,
    downloadReportFile: string,
    private readonly logManager: LogManager,
    private readonly reporter: Reporter
  ) {
    this.downloadReport = checkAbsolutePath(path.join(downloadsDirectoryPath, downloadReportFile))
  }

  /**
   * Получение экземпляра класса UpmManager
   * @param downloadsDirectoryPath - путь до директории с файлами, загруженными приложением FOTA.Connect
   * @param downloadReportFile - название файла со статусами загрузки файлов прошивок
   * @param LogManager - экземпляр класса LogManager
   */
  public static getInstance(
    downloadsDirectoryPath: string,
    downloadReportFile: string,
    LogManager: LogManager,
    reporter: Reporter
  ): UpmManager {
    if (!UpmManager.instance) {
      UpmManager.instance = new UpmManager(
        downloadsDirectoryPath,
        downloadReportFile,
        LogManager,
        reporter
      )
    }
    return UpmManager.instance
  }

  /**
   * HTTPs запрос на KAMAZ-CLOUD на загрузку манифеста пакета обновления
   //  * @param httpsRequestOptions - параметры HTTPs запроса
   //  * @param artifactLocal - данные о локальном артефакте (файле)
   //  * @param artifactUpdatePackManifest - данные об артефакте (файле) из локальной актуальной версии  Пакета Обновления
   */
  public downloadUpm(
    httpsRequestOptions: IHttpsRequestOptions | URL,
    UpmFileName: string,
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const fileStreamWriter = fs.createWriteStream(checkAbsolutePath(`${this.downloadsDirectoryPath}/${UpmFileName}`))
      const cb = (res: any) => {
        res.pipe(fileStreamWriter)
        res.on('data', (_data: any) => {
          fileStreamWriter.on('finish', () => {
            resolve()
          })
        })
        res.on('end', () => {
          this.logManager.info(`Update Packet Manifest downloaded successfully.`)
        })
      }
      let req
      if (process.env.NODE_ENV == 'development') {
        req = http.get(httpsRequestOptions, cb)
      }
      else {
        req = https.get(httpsRequestOptions, cb)
      }
      req.on('error', (e) => {
        if ('code' in e) {
          switch (e.code) {
            case 'ECONNREFUSED': {
              reject(new NoAvailableUrlError(`${httpsRequestOptions.host}${httpsRequestOptions.port ? `;${httpsRequestOptions.port}` : ''}/`))
              break
            }
            default: {
              this.logManager.log2Console('upm downloadUpm ', (e as Error))
              reject(new CustomError(e))
              break
            }
          }
        }
        else {
          this.logManager.log2Console('upm downloadUpm ', (e as Error))
          reject(new CustomError(e))
        }
      })
    })
  }

  /**
   * Проверка загруженных артефактов (файлов) и загрузка / возобновление загрузки артефактов (файлов) с KAMAZ-CLOUD
   * @param cloudDomainName - доменное имя серверного хранилища с прошивками
   * @param UpdatePackManifestData - объект данных из локальной актуальной версии Манифеста Пакета Обновления
   */
  public async downloadAndCheckArtifacts(
    httpsRequestOptions: IHttpsRequestOptions,
    upmData: IUpm,
  ): Promise<void> {
    const downloadArtifactRequestPromises: Promise<void>[] = []

    const arts = upmData.artifacts.sort((a, b) => a.type.localeCompare(b.type))

    this.report = fs.existsSync(this.downloadReport) ?
      JSON.parse(fs.readFileSync(this.downloadReport)
                   .toString()) :
      this.reporter.getTemplate(upmData, 'download')
    this.report.status = 'proccess'
    fs.writeFileSync(this.downloadReport, JSON.stringify(this.report))

    for (let artifact of arts) {
      const artifactLocal: IArtifactLocal = {
        ...artifact,
        file_path: checkAbsolutePath(`${this.downloadsDirectoryPath}/${artifact.file_name}`),
        file_exists: false,
        local_file_size: 0,
      }
      artifactLocal.file_exists = fs.existsSync(artifactLocal.file_path)

      let artifactFileSizeDelta = 0

      if (artifactLocal.file_exists) {
        // Получение размера загруженного файла прошивки
        artifactLocal.local_file_size = fs.statSync(artifactLocal.file_path).size
        artifactFileSizeDelta = artifactLocal.local_file_size - artifact.file_size

        if (artifactFileSizeDelta === 0) { // Файл загружен до конца
          this.logManager.info(`File ${artifact.file_name} is already downloaded.`)
          // ! Отключено
          // Сравнение хеш-сумм загруженного артефа и оригиналов
          // this.compareArtifactFilesHex(
          //   artifact.file_name,
          //   artifact.crc!,
          //   this.artifactLocal.file_path,
          // )
          continue
        }
        else if (artifactFileSizeDelta > 0) { // Размер артефакта (файла) превышает размер оригинала
          this.logManager.warn(`File size is incorrect! File ${artifact.file_name} is corrupted!`)

          // Запись статуса загрузки артефакта (файла) для FOTA.Master
          this.writedownArtifactDownloadStatus(artifact.artifact_id, 'error')

          this.logManager.info(`Trying to download ${artifact.file_name} again.`)

          // Повторная загрузка битого артефакта (файла)
          downloadArtifactRequestPromises.push(
            this.downloadArtifactRequest(
              httpsRequestOptions,
              artifactLocal,
              artifactFileSizeDelta,
            ),
          )
          continue
        }
      }

      httpsRequestOptions['path'] = artifact.url

      // if (artifact.type == ArtifactTypes.AES_IV || artifact.type == ArtifactTypes.AES_KEY) {
      //   await this.downloadArtifactRequest(
      //     httpsRequestOptions,
      //     artifactLocal,
      //     artifactFileSizeDelta,
      //   )
      // }
      // else {
        downloadArtifactRequestPromises.push(
          this.downloadArtifactRequest(
            httpsRequestOptions,
            artifactLocal,
            artifactFileSizeDelta,
          ),
        )
      // }
    }
    this.reporter.startReported(this.downloadReport)

    try {
      await Promise.all(downloadArtifactRequestPromises)
      this.logManager.log2Console('Download finish')
      this.report.status = 'done'
      this.report.artifacts.forEach((value) => value.status = 'done')
      fs.writeFileSync(this.downloadReport, JSON.stringify(this.report))
    } finally {
      this.reporter.stopReported(this.downloadReport)
    }
  }

  /**
   * HTTPs запрос на удалённый сервер KAMAZ-CLOUD на загрузку файлов прошивок
   * @param httpsRequestOptions - параметры HTTPs запроса
   * @param artifactLocal - данные о локальном артефакте (файле)
   * @param artifactUpdatePackManifest - данные об артефакте (файле) из локальной актуальной версии  Пакета Обновления
   */
  private downloadArtifactRequest(
    httpsRequestOptions: IHttpsRequestOptions,
    artifact: IArtifactLocal,
    artifactFileSizeDelta: number,
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      // Запись статуса загрузки файла прошивки для FOTA.Master
      let fileStreamWriter: WriteStream

      // Артефакта (файла) нет в локальной папке загрузок
      if (!artifact.file_exists || artifactFileSizeDelta > 0) {
        // или его размер превышает размер оригинала (в случае, если он есть соответственно)
        if (httpsRequestOptions.headers?.Range) {
          httpsRequestOptions.headers.Range = ''
        }
        fileStreamWriter = fs.createWriteStream(artifact.file_path)
      }
      // Артефакт (файл) есть в локальной папке загрузок, но он не загружен до конца
      else if (artifact.file_exists && artifactFileSizeDelta < 0) {
        fileStreamWriter = fs.createWriteStream(artifact.file_path, {
          flags: 'r+',
          start: artifact.local_file_size,
        })

        this.logManager.info(`File ${artifact.file_name} downloading has been resumed successfully.`)

        const startRange = artifact.local_file_size
        const endRange = artifact.file_size - 1

        httpsRequestOptions.headers = {'Accept-Ranges': 'bytes'}
        httpsRequestOptions.headers = {'Range': `bytes=${startRange}-${endRange}`}
      }

      const cb = (res: any) => {
        res.pipe(fileStreamWriter)
        this.writedownArtifactDownloadStatus(artifact.artifact_id, 'proccess')

        fileStreamWriter.on('finish', () => {
          // ! Отключено
          // Сравнение хеш-сумм загруженного артефа и оригиналов
          // this.compareArtifactFilesHex(
          //   artifactFileNameUpm,
          //   artifactCrcOriginal,
          //   artifactFilePathLocal
          // )
          // Запись статуса загрузки артефакта (файла) для FOTA.Master
          this.writedownArtifactDownloadStatus(artifact.artifact_id, 'done')
          this.logManager.log2Console(`File ${artifact.file_name} done`)
          resolve()
        })

        res.on('close', () => {
          const localSize = fs.statSync(checkAbsolutePath(artifact.file_path)).size
          if (localSize == artifact.file_size) {
            this.writedownArtifactDownloadStatus(artifact.artifact_id, 'done')
          }
          else {
            this.writedownArtifactDownloadStatus(artifact.artifact_id, 'wait')
            this.logManager.log2Console(`File ${artifact.file_name} close`)
          }

          resolve()
        })

        res.on('end', () => {
          this.writedownArtifactDownloadStatus(artifact.artifact_id, 'done')
          this.logManager.info(`File ${artifact.file_name} downloaded successfully.`)
        })
      };
      let req
      if (process.env.NODE_ENV == 'development') {
        req = http.get(httpsRequestOptions, cb)
      }
      else {
        if (httpsRequestOptions.host == 'fota.tmpdev.ru') {
          req = https.get(httpsRequestOptions, cb)
        }
        else {
          req = https.get(new URL(artifact.url), cb)
        }
      }

      req.on('error', (e) => {
        this.writedownArtifactDownloadStatus(artifact.artifact_id, 'error')
        if ('code' in e) {
          switch (e.code) {
            case 'ECONNREFUSED': {
              reject(new NoAvailableUrlError(`${httpsRequestOptions.host}${httpsRequestOptions.port ? `;${httpsRequestOptions.port}` : ''}/${httpsRequestOptions.path}`))
              break
            }
            default: {
              this.logManager.log2Console('upm downloadArtifactRequest ', (e as Error))
              reject(new CustomError(e))
              break
            }
          }
        }
        else {
          this.logManager.log2Console('upm downloadArtifactRequest ', (e as Error))
          reject(new CustomError(e))
        }
      })
    })
  }

  /**
   * Запись статуса загрузки артефакта (файла) для FOTA.Master
   */
  public writedownArtifactDownloadStatus = (
    artifactId: string,
    status: string
  ): void => {
    if (status == 'error'){
      this.report.status = 'error'
    }
    for (let artifact of this.report.artifacts) {
      if (artifact.artifact_id == artifactId) {
        artifact.status = status
      }
    }
    fs.writeFileSync(this.downloadReport, JSON.stringify(this.report))
  }

  /**
   * Получение хеш-суммы локального артефакта (файла)
   * @param artifactFilePathLocal - путь артефакту (файлу)
   */
  private calcArtifactLocalHex(artifactFilePathLocal: string): string {
    const artifactBufferLocal = fs.readFileSync(artifactFilePathLocal)
    const artifactHashSumLocal = crypto.createHash('sha256')
                                       .update(artifactBufferLocal)
    const artifactCrcLocal = artifactHashSumLocal.digest('hex')
    return artifactCrcLocal
  }

  // TODO: параметры
  /**
   * Cравнение хеш-сумм загруженного артефакта (файла) и оригинала
   */
  public compareArtifactFilesHex(
    artifactFileNameUpm: string,
    artifactCrcOriginal: string,
    artifactFilePathLocal: string,
  ): void {
    const artifactCrcLocal = this.calcArtifactLocalHex(artifactFilePathLocal)

    if (artifactCrcLocal !== artifactCrcOriginal) {
      this.logManager.warn(`HEX comparison failed! File ${artifactFileNameUpm} is corrupted!`)
      // TODO: перезапустить скачивание этого файла
      this.downloadAndCheckArtifacts
    }
    else if (artifactCrcLocal === artifactCrcOriginal) {
      this.logManager.info(`File ${artifactFileNameUpm} integrity is ok.`)
    }
  }

}
