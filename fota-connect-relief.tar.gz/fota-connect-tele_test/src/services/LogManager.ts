/**
 * LogManager — журналирование работы приложения
 */
import events from 'node:events'
import fs from 'node:fs'
import https from 'node:https'
import readline from 'node:readline'

import {
  ILogEntry,
  ILogLastEntry,
  IHttpsRequestOptions,
} from '../interfaces/interfaces'
import {checkAbsolutePath} from '../utils'

export class LogManager {
  private static instance: LogManager

  private minLevel: number
  private logLastEntryData = <ILogLastEntry>{}

  private readonly levels: { [key: string]: number } = {
    // 'trace': 1,
    'debug': 2,
    'info': 3,
    'warn': 4,
    'error': 5,
    'critical': 6
  }

  private constructor(
    logLevel: string,  // TODO: попробовать поменять уровень логгирования в конфиге
    private logsDirectoryPath: string,
    private logFile: string,
    private logLastEntryFile: string,
  ) {
    this.minLevel = this.levelToInt(logLevel) // TODO: попробовать поменять уровень логгирования в конфиге
  }

  /**
   * Метод конвертирует строковое значение logLevel ((trace)/debug/info/warn/error)
   * в соответствующее число (см. levels)
   * @param minLevel (logLevel) - глобальный уровень логгирования из конфига приложения env_config.json
   */
  private levelToInt(minLevel: string): number {
    if (minLevel.toLowerCase() in this.levels)
      return this.levels[minLevel.toLowerCase()]
    else
      return -1
  }

  /**
   * Метод пишет сообщения в консоль и в файл основного журнала приложения
   * @param logLevel - глобальный уровень логгирования из конфига приложения env_config.json
   * @param message - текст сообщения
   * @param code - код сообщения
   */
  private async log(logLevel: string, message: string, code: string): Promise<void> {
    const level = this.levelToInt(logLevel)

    if (level < this.minLevel)
      return

    const date = new Date()
    const newDate = new Date(date.getTime() + (3 * 60 * 60 * 1000))
    const formattedDate = newDate.toISOString().slice(0, 19).replace('T', ' ')

    const logEntry: ILogEntry = {
      unique_rnd: Math.random().toString(36).substring(2, 8) + Math.random().toString(36).substring(2, 8).toUpperCase(),
      // timestamp: `${new Date().toLocaleString()}`,
      timestamp: formattedDate,
      code: code,
      level: logLevel,
      message: message
    }

    const msgTerminal = `[${logEntry.timestamp}] [${logEntry.code}] [${logEntry.level}] ${logEntry.message}`
    const msgLogFile = `[${logEntry.unique_rnd}] [${logEntry.timestamp}] [${logEntry.code}] [${logEntry.level}] ${logEntry.message}`

    if (process.env.DEBUG != undefined) {
      switch (logEntry.level) {
        // case 'TRACE':
        //   console.trace(msgTerminal)
        //   break
        case 'DEBUG':
          console.debug(msgTerminal)
          break
        case 'INFO':
          console.info(msgTerminal)
          break
        case 'WARN':
          console.warn(msgTerminal)
          break
        case 'ERROR':
          console.error(msgTerminal)
          break
        case 'CRITICAL':
          console.error(msgTerminal)
          break
        default:
          console.log(`{${logEntry.level}} ${msgTerminal}`)
      }
    }

    // TODO: 
    // Проверить как будет, если писать (и как так писать?) из объекта
    // fs.writeFileSync
    // fs.appendFileSync
    // fs.createWriteStream
    fs.writeFileSync(checkAbsolutePath(`${this.logsDirectoryPath}/${this.logFile}`), `${msgLogFile}\n`, {flag: 'a+'})
  }

  // public trace(message: string): void { this.log('TRACE', message, '101') }
  public debug(message: string): void {
    this.log('DEBUG', message, '201')
  }

  public info(message: string): void {
    this.log('INFO', message, '301')
  }

  public warn(message: string): void {
    this.log('WARN', message, '401')
  }

  public error(message: string): void {
    this.log('ERROR', message, '501')
  }

  public critical(message: string): void {
    this.log('CRITICAL', message, '555')
  }

  public log2Console = (message?: any, ...optionalParams: any[]) => {
    if (process.env.DEBUG != undefined) {
      console.log(message, optionalParams)
    }
  }

  // TODO: fileManager
  /**
   * Метод получения экземпляра класса LogManager
   * @param logLevel - глобальный уровень логгирования из конфига приложения env_config.json // ! Скоро будет в  Пакета Обновления
   * @param logsDirectoryPath - путь до директории с файлом основного журнала приложения
   * @param logFile - имя файла основного журнала приложения
   * @param logLastEntryFile - имя файла, содержащего последнюю отправленную запись основного журнала приложения на FOTA.Cloud
   */
  public static getInstance(
    logLevel: string,
    logsDirectoryPath: string,
    logFile: string,
    logLastEntryFile: string,
  ): LogManager {
    if (!LogManager.instance)
      LogManager.instance = new LogManager(logLevel, logsDirectoryPath, logFile, logLastEntryFile)

    return LogManager.instance
  }

  /**
   * Метод отправляет отчёт (часть основного журнала работы приложения) на FOTA.Cloud  // ! возожно, будет реализация отправки отчёта целым файлом, а не потоком
   * @param cloudDomainName - доменное имя FOTA.Cloud
   * @param blockIdMasterConfig - ID блока ТМП из файла конфигурации от FOTA.Master и локальной ОС
   * @param logLastEntryDirectory - название директории с файлом, содержащим информацию о последней отправленной записи основного журнала приложения на FOTA.Cloud
   * @param logLastEntryData - значение последней отправленной записи основного журнала приложения на FOTA.Cloud, находящееся в локальном файле data/fota_connect_log_last_entry.json
   */
  public sendLogFileToCloud(
    cloudDomainName: string,
    blockIdMasterConfig: string,
    logLastEntryDirectory: string,
    logLastEntryData: ILogLastEntry | null
  ): Promise<void> {
    const httpsRequestOptions = <IHttpsRequestOptions>{}
    httpsRequestOptions.host = cloudDomainName
    httpsRequestOptions.path = `/report`
    httpsRequestOptions.headers = {
      // 'Content-Type': 'multipart/form-data', // ! возожно, будет реализация отправки отчёта целым файлом, а не потоком
      'Fota-Connect-Block-ID': blockIdMasterConfig
    }

    if (logLastEntryData)
      this.logLastEntryData.entry_unique_id = logLastEntryData.entry_unique_id

    return new Promise(async (resolve, reject) => {
      try {
        const req = https.request({method: 'POST', ...httpsRequestOptions}, res => {
          const chunks: Array<Buffer> = []
          res.on('data', data => chunks.push(data))
          res.on('end', () => {
            const resBodyJSON = JSON.parse(Buffer.concat(chunks).toString())

            this.logLastEntryData.entry_unique_id = `${resBodyJSON.unique_key} ${resBodyJSON.timestamp}`
            fs.writeFileSync(`${logLastEntryDirectory}/${this.logLastEntryFile}`, `${JSON.stringify(this.logLastEntryData)}\n`)

            resolve()
          })
        })

        // TODO: вынести в переменную класса (и все такие места)
        const logFileExists = fs.existsSync(checkAbsolutePath(`${this.logsDirectoryPath}/${this.logFile}`))

        if (logFileExists) {
          if (!this.logLastEntryData.entry_unique_id) {
            const logFileStreamReader = fs.createReadStream(checkAbsolutePath(`${this.logsDirectoryPath}/${this.logFile}`))
            logFileStreamReader.pipe(req)
            logFileStreamReader.on('end', () => {
              req.end()
            })
          } else {
            const rl = readline.createInterface({
              input: fs.createReadStream(checkAbsolutePath(`${this.logsDirectoryPath}/${this.logFile}`)),
              crlfDelay: Infinity
            })

            let counter = 0

            rl.on('line', (line) => {
              if (line.indexOf(this.logLastEntryData.entry_unique_id!) != -1) {
                counter++
              }

              if (line.indexOf(this.logLastEntryData.entry_unique_id!) == -1 && counter > 0) {
                req.write(`${line}\n`)
              }
            })

            await events.once(rl, 'close')

            // this.LogManager.info('Reading file line by line with readline done.')
            // const used = process.memoryUsage().heapUsed / 1024 / 1024
            // this.LogManager.info(`The script uses approximately ${Math.round(used * 100) / 100} MB`)
            // --------
            // const form = new URLSearchParams()
            // const form = new FormData()
            // form.append('log_file', logFileStreamReader as any)
            // form_URLSearchParams.append('log_file_form_URLSearchParams', fs.createReadStream(logFilePath) as any)

            // if (body) {
            //   req.write(JSON.stringify(body))
            // }
            // --------

            req.on('error', (e) => {
              // TODO: reject()
              this.error(`${(e as Error).message}; Readable stream interrupted!`)
              // TODO:
            })

            req.end()
          }
        } else {
          // TODO: reject()
          this.error('There is no log file!')
        }
      } catch (e) {
        this.error(`${(e as Error).message}`)
      }
    })
  }
}
