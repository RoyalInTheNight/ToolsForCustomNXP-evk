import {checkAndMakeDir, fotaEventEmitter} from '../utils'
import {ArtifactTypes, eventNames} from '../enums/enums'
import {LogManager, Reporter} from '.'
import fs from 'node:fs'
import path from 'path'
import crypto from 'node:crypto'
import {checkAbsolutePath} from '../utils'
import {IArtifactUpm, IReport, IUpm} from "../interfaces/interfaces";

class CryptoManager {
  private static instance: CryptoManager
  private blockPrivateKey: string
  private aesIv: Buffer | null
  private aesKeyEncrypted: Buffer | null
  private aesKeyDecrypted: Buffer | null
  private reporter: Reporter
  private reportPath: string
  private report: IReport = <IReport>{}

  private constructor(
    readonly downloadsDirectoryPath: string,
    decryptReport: string,
    privatePemPath: string,
    readonly logManager: LogManager,
    reporter: Reporter
  ) {
    this.blockPrivateKey = fs.readFileSync(checkAbsolutePath(privatePemPath))
                             .toString()
    this.aesIv = null
    this.aesKeyEncrypted = null
    this.aesKeyDecrypted = null
    this.reportPath = checkAbsolutePath(path.join(downloadsDirectoryPath, decryptReport))
    this.reporter = reporter
  }

  /**
   * Метод получения экземпляра класса CryptoManager
   */
  public static getInstance(
    downloadsDirectoryPath: string,
    decryptReport: string,
    privatePemPath: string,
    logManager: LogManager,
    reporter: Reporter
  ): CryptoManager {
    if (!CryptoManager.instance) {
      CryptoManager.instance = new CryptoManager(downloadsDirectoryPath, decryptReport, privatePemPath, logManager, reporter)
    }
    return CryptoManager.instance
  }

  public decryptArtifacts(upm: IUpm) {
    const artifacts = upm.artifacts
    const arts = artifacts.sort((a, b) => a.type.localeCompare(b.type))

    this.report = fs.existsSync(this.reportPath) ?
      JSON.parse(fs.readFileSync(this.reportPath)
                   .toString()) :
      this.reporter.getTemplate(upm, 'decrypt')

    this.report.status = 'proccess'
    this.report.artifacts = this.report.artifacts.filter(value => value.type == ArtifactTypes.FIRMWARE)

    fs.writeFileSync(this.reportPath, JSON.stringify(this.report))

    this.reporter.startReported(this.reportPath)
    for (let artifact of arts) {

      const report_artifact = this.report.artifacts.find(value => value.artifact_id == artifact.artifact_id)

      if (artifact.type == ArtifactTypes.FIRMWARE && (!report_artifact || report_artifact.status == 'done')) continue

      if (report_artifact) report_artifact.status = 'proccess'
      fs.writeFileSync(this.reportPath, JSON.stringify(this.report))

      this.decrypt(artifact)

      if (report_artifact) report_artifact.status = 'done'
      fs.writeFileSync(this.reportPath, JSON.stringify(this.report))
    }

    this.report.status = 'done'

    this.reporter.stopReported(this.reportPath)
  }

  private decrypt(artifact: IArtifactUpm) {
    const encryptFile = fs.readFileSync(checkAbsolutePath(`${this.downloadsDirectoryPath}/${artifact.file_name}`))
    switch (artifact.type) {
      case ArtifactTypes.AES_IV: {
        this.aesIv = encryptFile
        break
      }
      case ArtifactTypes.AES_KEY: {
        this.aesKeyEncrypted = encryptFile
        this.aesKeyDecrypted = crypto.privateDecrypt(
          {
            key: this.blockPrivateKey,
            padding: crypto.constants.RSA_PKCS1_PADDING,
            passphrase: '11111',
          },
          this.aesKeyEncrypted!,
        )
        break
      }
      default: {
        const decipher = crypto.createDecipheriv('aes-256-cfb8', this.aesKeyDecrypted!, this.aesIv!)
        let decrypted = decipher.update(encryptFile)
        decipher.final()
        checkAndMakeDir(checkAbsolutePath(`${this.downloadsDirectoryPath}/decrypted`))
        fs.writeFileSync(checkAbsolutePath(`${this.downloadsDirectoryPath}/decrypted/${artifact.file_name}`), decrypted)
      }
    }
    this.logManager.info(`File ${artifact.file_name} encrypted successfully.`)
  }

  public encrypt(data: string): string {
    return data
  }

}

export {
  CryptoManager,
}