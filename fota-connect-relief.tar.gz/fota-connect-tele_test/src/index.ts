/**
 * Корневой файл проекта, запускает приложение FOTA.Connect
 */
import fs from 'node:fs'

import {App} from './app'

let envConfigDataRaw: Buffer

if (process.platform !== 'linux') {
  /**
   * Если приложение запускается не на linux
   */
  console.warn('Please, restart app Linux.')
  process.exit(0)
}

switch (process.env.NODE_ENV) {
  case 'development': {
    envConfigDataRaw = fs.readFileSync('/etc/fota/fota_connect_dev.conf')
    break
  }
  default: {
    envConfigDataRaw = fs.readFileSync('/etc/fota/fota_connect.conf')
    break
  }
}

const envConfigDataParsed = JSON.parse(envConfigDataRaw.toString())

const fotaMasterConfigPath = `${envConfigDataParsed.CONFIG_DATA_DIRECTORY_PATH}/${envConfigDataParsed.MASTER_CONFIG_FILE}`
const fotaMasterConfigDataRaw = fs.readFileSync(fotaMasterConfigPath)
const fotaMasterConfigDataParsed = JSON.parse(fotaMasterConfigDataRaw.toString())

// Уникальный идентификатор блока
const {blocks: [blockId]} = fotaMasterConfigDataParsed
const {block_login: blockLogin} = fotaMasterConfigDataParsed

const app = App.getInstance(envConfigDataParsed, blockId, blockLogin)

;(async () => await app.start())()
