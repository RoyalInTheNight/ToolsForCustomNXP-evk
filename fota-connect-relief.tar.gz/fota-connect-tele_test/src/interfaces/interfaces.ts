import {logLevel, mPacketTitles} from './../enums/enums'

// Интерфейсы в приложении
interface IEnv {
  VERSION: string
  OS_VERSION: string
  KAMAZ_CLOUD_HOST: string
  KAMAZ_CLOUD_PORT: string
  CONFIG_DATA_DIRECTORY_PATH: string
  DOWNLOADS_DIRECTORY_PATH: string
  LOGS_DIRECTORY_PATH: string
  ENV_CONFIG_FILE: string
  MASTER_CONFIG_FILE: string
  UPDATE_PACK_MANIFEST_FILE: string
  DOWNLOAD_REPORT_FILE: string,
  DECRYPT_REPORT_FILE: string,
  INSTALL_REPORT_FILE: string,
  LOG_FILE: string
  LOG_LAST_ENTRY_FILE: string
  LOG_LEVEL: string
  TIME_DELAY_READ_DISCOVERY: string
  NET_INTERFACE: string
  PRIVATE_PEM_PATH: string
  PUBLIC_PEM_PATH: string
  FOTA_IPC_SOCKET_PATH: string    // ?  os.tmpdir() // /tmp
  RELIEF_IPC_SOCKET_PATH: string  // ?  os.tmpdir() // /tmp
  TELE_IPC_SOCKET_PATH: string    // ?  os.tmpdir() // tmp
  DISCOVERY_MANAGER: boolean,
  TELE_MANAGER: boolean,
  FOTA_MANAGER: boolean
}

interface IUpm {
  packet_id: string
  model: string
  version: string
  // block_login?: string
  // encryption_key?: string
  artifacts: IArtifactUpm[]
}

interface IArtifactUpm {
  artifact_id: string
  file_name: string
  file_size: number
  type: string
  version: string
  url: string
  crc?: string
}

interface IReport {
  packet_id: string
  version: string
  stage: string
  status: string
  artifacts: IArtifactReport[]
}

interface IArtifactReport {
  artifact_id: string
  file_name: string
  type: string
  status: string
}


interface IArtifactLocal extends IArtifactUpm {
  local_file_size: number
  file_path: string
  file_exists: boolean
}

interface IArtifactDownloadStatus extends IArtifactUpm {
  download_status_code: number
}

interface ILogEntry {
  unique_rnd: string
  timestamp: string
  code: string
  level: string
  module?: string
  location?: string
  message: string
}

interface ILogLastEntry {
  entry_unique_id?: string
}

interface IHttpsRequestOptions {
  host?: string
  port?: string
  path: string
  headers?: {
    [key: string]: string
  }
}

interface IFotaError {
  message: string,
  _logLevel: logLevel
}

interface IMPacketMessage {
  title: mPacketTitles,
  message: string
}

// ? TODO: это ненужные интерфейсы 
interface IFotaMasterIpcSignals {
  'FOTA.Start': boolean | Buffer
  'FOTA.Finish': boolean | Buffer
}

interface ITeleMasterIpcSignals {
  'TELE.Start': boolean | Buffer
  'TELE.Finish': boolean | Buffer
  'TELE.Buf': Array<boolean | Buffer> // ? TODO: какой тип данных именно внутри массива?
}

interface IReliefMasterIpcSignals {
  'REL.Start': boolean | Buffer
  'REL.Finish': boolean | Buffer
  'REL.Data': string // ? TODO: точно строка ?
}

export {
  IEnv,
  IUpm,
  IArtifactUpm,
  IArtifactLocal,
  IArtifactDownloadStatus,
  ILogEntry,
  ILogLastEntry,
  IHttpsRequestOptions,
  IFotaError,
  IMPacketMessage,
  IReport,
  IArtifactReport,

  IFotaMasterIpcSignals,
  ITeleMasterIpcSignals,
  IReliefMasterIpcSignals
}
