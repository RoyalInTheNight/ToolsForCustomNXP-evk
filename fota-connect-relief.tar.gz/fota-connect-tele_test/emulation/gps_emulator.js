const net = require('node:net')
const fs = require('node:fs')

const socketPath = '/tmp/gps.sock'

if (fs.existsSync(socketPath)) fs.unlinkSync(socketPath)

const server = net.createServer((connection) => {
   // 'connection' listener.
   console.log('client connected')

   connection.on('end', () => {
      console.log('client disconnected')
   })

   const sendCord = () => {
      // console.log('I\'m server\'s console.log')
      const cord = '$GPRMC,125504.049,A,5542.2389,N,03741.6063,E,0.06,25.82,200906,,,,*17'
      connection.write(cord)
      setTimeout(sendCord, 300*1000)
   }
   sendCord()

   connection.on('data', (data) => {
      console.log('I\' data received from client: ', data.toString())
   })

   connection.pipe(connection) // ?
})

server.on('error', (err) => {
   throw err
})

server.on('listening', () => {
   console.log(32, 'server.on(\'listening\')')
})

server.listen(socketPath, () => {
   console.log('server bound')
})

console.log('socket_server_pid', process.pid)
console.log('socket_server_ppid', process.ppid)

process.on('SIGINT', () => {
   console.log('\nCaught interrupt signal: shutting down TELE.Master emulator.')
   fs.unlinkSync('/tmp/gps.sock') // Удаление созданного сокета из файловой системы
   process.exit(0)
})