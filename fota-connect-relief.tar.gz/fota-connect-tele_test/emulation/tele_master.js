const fs = require('node:fs')
const net = require('node:net')
const os = require('node:os')
const path = require('node:path')

const TELE_IPC_SOCKET_PATH = '/tmp/tele.sock'
const GPS_SOCKET_PATH = '/tmp/gps.sock'

const teleMasterIpcSignals = {}

// TODO: Buffer.from[0] // [1]
let teleFinishIpcSignal

let teleBuf = []
/**
 * Сокет соединения с FOTA.Connect
 * */
let teleMasterFotaConnection
// должно поддерживаться только одно подключение с определённого клиента
let nmeaData

//Для запуска TELE.Master сначала пожключаемся к gps_emulator
if (fs.existsSync(TELE_IPC_SOCKET_PATH)) fs.unlinkSync(TELE_IPC_SOCKET_PATH)

const gpsServer = net.createConnection(GPS_SOCKET_PATH)
    .on('error', (e) => {
        console.log(`There is no connection to GPS emulator: ${e.message}! Emergency process termination!`)
        process.exit(1)
    })

gpsServer.on('connect', () => {
    console.info('Connected to GPS Emulator successfully.')

    //Запускаем TELE.Master
    const server = net.createServer((connection) => { // (connection) callback is an optional 'connection' listener.
        console.log('Client connected to TELE.Master.')
        teleMasterFotaConnection = connection

        connection.on('data', (data) => { // data: <string> | <Buffer> | <Uint8Array>

            // ! остановился здесь
            // console.log(74, data.toString())

            // {"TELE.Start":{"type":"Buffer","data":[1]}}
            // const dataDecoded = decodeURIComponent(String.fromCharCode(...data)) // data: <Uint8Array>

            // { 'TELE.Start': { type: 'Buffer', data: [ 1 ] } }
            // const dataDecodedParsed = JSON.parse(dataDecoded)

            // Если установлен TELE.Start (TELE.Start === 1 (true))
            // if (dataDecodedParsed['TELE.Start'].data[0] === 1) {
            //
            //     // Сбрасывает TELE.Finish === 0 (false)
            //     teleMasterIpcSignals['TELE.Finish'] = Buffer.from([0])
            //     const teleMasterIpcSignalsUint8Array = new TextEncoder().encode(JSON.stringify(teleMasterIpcSignals))
            //     setTimeout(()=>connection.write(teleMasterIpcSignalsUint8Array), 500)
            //
            //     // Если сброшен TELE.Start (TELE.Start === 0 (false))
            // } else if (dataDecodedParsed['TELE.Start'].data[0] === 0) {
            //     teleMasterIpcSignals['TELE.Buf'] = nmeaData
            //     teleMasterIpcSignals['TELE.Finish'] = Buffer.from([1])
                // console.log(75, teleMasterIpcSignals)
                // const teleMasterIpcSignalsUint8Array = new TextEncoder().encode(nmeaData)
                // setTimeout(() => connection.write(teleMasterIpcSignalsUint8Array),500)
            // }

        })

        setTimeout(() => connection.write('hello world'),500)

        connection.on('end', () => {
            console.log('TELE IPC client disconnected from TELE.Master IPC server.')
            // TODO: протестировать 2 строчки ниже
            connection.removeAllListeners('data')
            connection.removeAllListeners('error')
        })

    })
    server.on('error', (e) => {
        fs.unlinkSync(TELE_IPC_SOCKET_PATH) // Удаление созданного сокета из файловой системы
        throw e
    })
    server.listen(TELE_IPC_SOCKET_PATH, (server) => {
        console.log('TELE.Master emulator is up and running.')
    })

})

gpsServer.on('close', () => {
    console.warn('IPC socket connection has been closed by GPS Emulator.')
    process.exit(0)
})
gpsServer.on('data', (data) => { // data: <string> | <Buffer> | <Uint8Array>
    // console.log(`gpsData ${data.toString()}`)
    const teleMasterIpcSignalsUint8Array = new TextEncoder().encode(data)
    if (teleMasterFotaConnection) {
        setTimeout(() => teleMasterFotaConnection.write(data), 500)
    }
    // nmeaData = data
})
gpsServer.on('error', (e) => {
    console.log(`There is no connection to GPS emulator: ${e.message}! Emergency process termination!`)
    process.exit(1)
})

// Код для отладки в ходе разработки (сочетание клавиш CTRL+C):
process.on('SIGINT', () => {
    console.log('\nCaught interrupt signal: shutting down TELE.Master emulator.')
    fs.unlinkSync(TELE_IPC_SOCKET_PATH) // Удаление созданного сокета из файловой системы
    process.exit(0)
})
