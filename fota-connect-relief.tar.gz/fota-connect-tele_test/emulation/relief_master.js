// /var/run/fota/fota.sock
// или /run/fota/fota.sock
// домен соединения: PF_UNIX,PF_LOCAL
// тип: SOCK_STREAM

// TODO: сделать загрузку при старте виртуальной машины (см. ota.service)
// TODO: попробовать создать ссылку в /run (см. также ota.service)
// ln -s <source_file> <symbolic_link>

// -f — remove existing destination files
// ln -sf /var/lib/mysql/mysql.sock /tmp/mysql.sock

// rm /tmp/fota.sock
// const socketPath = '/tmp/fota/fota.sock'
// const socketPath = '/tmp/fota.sock'

//------------------------------------------------------------------------//

// Сокращенное (упрощенное) описание алгоритма обмена данными
// REL.Connect не обращается к Параметрам от GNSS-приемника LC79D после установки сигнала REL.Start
// REL.Connect устанавливает сигнал REL.Start
// REL.Master ожидает установки сигнала REL.Start и после установки сбрасывает сигнал REL.Finish
// REL.Connect ожидает сброса сигнала REL. Finish и после сброса сбрасывает сигнал REL.Start
// REL.Master ожидает сброса сигнал REL.Start  и после сброса выполняет запись Параметров от GNSS-приемника LC79D, далее не обращается к ним после установки сигнала REL.Finish.
// REL.Master устанавливает сигнал REL.Finish
// REL.Connect ожидает установки сигнала REL. Finish и после установки считывает Параметры от GNSS-приемника LC79D

//------------------------------------------------------------------------//