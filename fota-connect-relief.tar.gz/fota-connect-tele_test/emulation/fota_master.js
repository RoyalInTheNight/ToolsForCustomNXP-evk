const fs = require('fs')
const net = require('net')
const os = require('os')
const path = require('path')

const checkAbsPath = (_path) => path.isAbsolute(_path) ? _path : path.join(process.cwd(), _path)
let configDataRaw

switch (process.env.NODE_ENV) {
   case 'development':
      fs.readFileSync(checkAbsPath('./../data/fota_master.conf'))
      break
   case 'production':
      configDataRaw = fs.readFileSync('/etc/fota/fota_master.conf')
      break
   default:
      /**
       * Если не указан тип окружения в переменной окружения NODE_ENV, завершить работу с просьбой перезапуска
       * приложения с одним из соответствующих значений
       */
      console.warn('Please, restart app with \'development\' or \'production\' NODE_ENV variable value.')
      process.exit(0)
}

const configDataParsed = JSON.parse(configDataRaw.toString())

const { FOTA_IPC_SOCKET_PATH } = configDataParsed
const { FIRMWARE_DIRECTORY_PATH } = configDataParsed
const { FIRMWARE_INSTALLATION_STATUS_FILE } = configDataParsed

const fotaMasterIpcSignals = {}

// TODO: Buffer.from[0] // [1]
let fotaFinishIpcSignal

// let firmwareInstalled = false

function randomResultFirmware() {
   return Math.round(2 * Math.random())
}

if (fs.existsSync(FOTA_IPC_SOCKET_PATH)) fs.unlinkSync(FOTA_IPC_SOCKET_PATH)

// должно поддерживаться только одно подключение с определённого клиента
const server = net.createServer((connection) => { // (connection) callback is an optional 'connection' listener.
   console.log('Client connected to FOTA.Master.')

   connection.on('data', (data) => { // data: <string> | <Buffer> | <Uint8Array>

      // {"FOTA.Start":{"type":"Buffer","data":[1]}}
      const dataDecoded = decodeURIComponent(String.fromCharCode(...data)) // data: <Uint8Array>

      // { 'FOTA.Start': { type: 'Buffer', data: [ 1 ] } }
      // !!! ОШИБКА // !! ОБРАБРАТЬ ЕЕ, ОНА НЕ ПОПАДАЕТ ПОД ОБРАБОТКУ И СОКЕТ ОСТАЕТСЯ В ФАЙЛОВОЙ СИСТЕМЕ
      const dataDecodedParsed = JSON.parse(dataDecoded)
      // console.log(102, 'fota_master.js: dataDecodedParsed ', dataDecoded)

      if (dataDecodedParsed['FOTA.Start'].data[0] === 1) { // Если установлен FOTA.Start (FOTA.Start === 1 (true))
         fotaMasterIpcSignals['FOTA.Finish'] = Buffer.from([0]) // Сбрасывает FOTA.Finish (FOTA.Finish === 0 (false))
         const fotaMasterIpcSignalsUint8Array = new TextEncoder().encode(JSON.stringify(fotaMasterIpcSignals))
         connection.write(fotaMasterIpcSignalsUint8Array)
      }
      else if (dataDecodedParsed['FOTA.Start'].data[0] === 0) { // Если сброшен FOTA.Start (FOTA.Start === 0 (false))
         const date = new Date()
         const newDate = new Date(date.getTime() + (3 * 60 * 60 * 1000))
         const formattedDate = newDate.toISOString().slice(0, 19).replace('T', ' ')

         setTimeout(() => {
            const firmwareUpdateData = {
               timestamp: formattedDate,
               message: 'Firmware has been successfully installed on TMP by FOTA.Master.',
            }
            const data = []

            const p = checkAbsPath(`${FIRMWARE_DIRECTORY_PATH}/decrypted`)
            const p1 = checkAbsPath(`${FIRMWARE_DIRECTORY_PATH}/${FIRMWARE_INSTALLATION_STATUS_FILE}`)
            // Создание и запись в fota_master_result.json
            try {
               const artifacts = fs.readdirSync(p)
               for (let artifact of artifacts) {
                  data.push({
                     timestamp: formattedDate,
                     file_name: artifact,
                     flashing_status_code: randomResultFirmware(),
                  })
               }
               if (10 * Math.random() < 2) {
                  fs.writeFileSync(p1, JSON.stringify(data))
               }
               else {
                  if (fs.existsSync(p1)) {
                     fs.rmSync(p1)
                  }
               }
            }
            catch (e) {
               // console.log(143, `fota_master.js emulator: ${e.message}`)
               fs.writeFileSync(p1, `${JSON.stringify([firmwareUpdateData])}\n`)
            }

            fotaMasterIpcSignals['FOTA.Finish'] = Buffer.from([1])

            const fotaMasterIpcSignalsUint8Array = new TextEncoder().encode(JSON.stringify(fotaMasterIpcSignals))
            connection.write(fotaMasterIpcSignalsUint8Array)

         }, 5000)
      }

      // ! FotaMasterManager.ts
      // this.fotaIpcClient.write('FOTA.Start\r\n')
      // this.fotaIpcClient.write(this.fotaMasterIpcSignals['FOTA.Start'])

      // ! 1. fota_master.js emulator
      // FOTA.Start
      // if (data.length > 1) {
      //   console.log(65, data.toString())
      //   // <Buffer 01> // true
      // } else if (data.length == 1) {
      //   console.log(data)
      // }

      // ! 2. fota_master.js emulator

      // switch(data.toString) {
      //   case 'FOTA.Start':
      //     // ? TODO: распознать сообщение как сигнал FOTA.Start
      //     break
      //   case 'FOTA.Finish':
      //     // ? TODO: распознать сообщение как сигнал FOTA.Finish
      //     break
      //   default:
      //     break
      // }

      // Пример для 'FOTA.Start' = true ————> { type: 'Buffer', data: [ 1 ] }
      // incomingDataParsed = JSON.parse(JSON.stringify(data))

      // if (incomingDataParsed?.data?.length == 1) {
      //   switch(Number(incomingDataParsed.data[0])) {
      //     case 1:
      //       // ? TODO: распознать состояние сигнала как установленного (true)
      //       break
      //     case 0:
      //       // ? TODO: распознать состояние сигнала как сброшенного (false)
      //       break
      //     default:
      //       break
      //   }
      // }
   })

   connection.on('end', () => {
      console.log('FOTA IPC client disconnected from FOTA.Master IPC server.')
      // TODO: протестировать 2 строчки ниже
      connection.removeAllListeners('data')
      connection.removeAllListeners('error')
   })
})

server.on('error', (e) => {
   fs.unlinkSync(FOTA_IPC_SOCKET_PATH) // Удаление созданного сокета из файловой системы
   throw e
})

server.listen(FOTA_IPC_SOCKET_PATH, (server) => {
   console.log('FOTA.Master emulator is up and running.')
})

// Код для отладки в ходе разработки (сочетание клавиш CTRL+C):
process.on('SIGINT', () => {
   console.log('\nCaught interrupt signal: shutting down FOTA.Master emulator.')
   fs.unlinkSync(FOTA_IPC_SOCKET_PATH) // Удаление созданного сокета из файловой системы
   process.exit(0)
})

// дать соответствующие права сокету, проверить, какие именно
// fs.chmod(FOTA_IPC_SOCKET_PATH, 0o666)
